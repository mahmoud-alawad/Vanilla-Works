#!/bin/bash

################################################################################
# COMMAND: CONFIG
# Configuration management (show, edit, validate)
################################################################################

cmd_config() {
    if [[ $# -eq 0 ]]; then
        printf "${CYAN}fb config${NC} - Configuration management\n"
        printf "\n${BLUE}USAGE:${NC}\n"
        printf "    fb config [SUBCOMMAND]\n"
        printf "\n${BLUE}SUBCOMMANDS:${NC}\n"
        printf "    show                Show current configuration\n"
        printf "    edit                Edit configuration\n"
        printf "    validate            Validate configuration\n"
        printf "\n"
        return
    fi

    local subcommand="$1"
    shift || true

    case "$subcommand" in
        show) cmd_config_show "$@" ;;
        edit) cmd_config_edit "$@" ;;
        validate) cmd_config_validate "$@" ;;
        *)
            log_error "Unknown subcommand: $subcommand"
            return 1
            ;;
    esac
}

cmd_config_show() {
    load_config "$SITES_CONFIG" || return 1

    log_section "Current Configuration"

    jq '.' "$SITES_CONFIG"
}

cmd_config_edit() {
    load_config "$SITES_CONFIG" || return 1

    log_info "Opening configuration in editor..."
    ${EDITOR:-code} "$SITES_CONFIG"
}

cmd_config_validate() {
    load_config "$SITES_CONFIG" || return 1

    log_section "Validating Configuration"

    # Check structure
    local has_project=$(jq 'has("projectName")' "$SITES_CONFIG")
    local has_global=$(jq 'has("global")' "$SITES_CONFIG")
    local has_sites=$(jq 'has("sites")' "$SITES_CONFIG")

    if [[ "$has_project" != "true" ]] || [[ "$has_global" != "true" ]] || [[ "$has_sites" != "true" ]]; then
        log_error "Configuration structure is invalid"
        return 1
    fi

    log_success "Configuration is valid"
}
