#!/bin/bash

################################################################################
# COMMAND: SITE
# WordPress site management (add, list, remove, info, configure)
################################################################################

cmd_site() {
    if [[ $# -eq 0 ]]; then
        printf "${CYAN}fb site${NC} - Manage WordPress sites\n"
        printf "\n${BLUE}USAGE:${NC}\n"
        printf "    fb site [SUBCOMMAND] [OPTIONS]\n"
        printf "\n${BLUE}SUBCOMMANDS:${NC}\n"
        printf "    add [NAME]          Add new WordPress site\n"
        printf "    list                List all configured sites\n"
        printf "    info [NAME]         Show site information\n"
        printf "    remove [NAME]       Remove site\n"
        printf "    configure [NAME]    Configure site settings\n"
        printf "\n"
        return
    fi

    local subcommand="$1"
    shift || true

    case "$subcommand" in
        add) cmd_site_add "$@" ;;
        list) cmd_site_list "$@" ;;
        info) cmd_site_info "$@" ;;
        remove) cmd_site_remove "$@" ;;
        configure) cmd_site_configure "$@" ;;
        *)
            log_error "Unknown subcommand: $subcommand"
            return 1
            ;;
    esac
}

cmd_site_add() {
    load_config "$SITES_CONFIG" || return 1

    log_section "Add New WordPress Site"

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    # Validate site name
    if ! [[ "$site_name" =~ ^[a-z0-9-]+$ ]]; then
        log_error "Site name must contain only lowercase letters, numbers, and hyphens"
        return 1
    fi

    # Check if already exists
    if site_exists "$site_name"; then
        log_error "Site '$site_name' already exists"
        return 1
    fi

    # Interactive prompts
    printf "\n"
    local domain=$(prompt "Domain name" "$site_name.localhost")

    local php_choices="8.2, 8.1, 8.0, 7.4, 7.3"
    printf "PHP version ($php_choices) [8.1]: "
    read -r php_version
    php_version="${php_version:-8.1}"

    local admin_email=$(prompt "Admin email" "developer@$site_name.localhost")

    printf "\n"
    if prompt_confirm "Fresh WordPress installation?" "y"; then
        local fresh_install="true"
    else
        local fresh_install="false"
    fi

    # Remote server domain (optional) - for URL replacement during restore
    log_info "Remote server configuration (optional, for database migration)"
    local remote_server=""
    if prompt_confirm "Do you have an existing site to migrate from?"; then
        remote_server=$(prompt "Remote server domain" "example.com")
    fi

    # FTP credentials (optional)
    local ftp_host=""
    local ftp_user=""
    local ftp_pass=""
    local ftp_path="/"

    if prompt_confirm "Do you have an online site to import media from (via FTP)?"; then
        ftp_host=$(prompt "Online FTP Host")
        ftp_user=$(prompt "Online FTP Username")
        printf "Online FTP Password: "
        read -rs ftp_pass
        printf "\n"
        ftp_path=$(prompt "Online FTP Path" "/")
    fi

    # Load global config for defaults
    load_env "$ENV_FILE"

    local db_name="${site_name}_wp"
    local db_user="root"
    local db_pass="${DB_ROOT_PASSWORD:-Admin123}"
    local admin_user="${ADMIN_USER:-developer}"
    local admin_pass="${ADMIN_PASSWORD:-Farmerdev#17}"
    local theme="${DEFAULT_THEME:-farmerbit}"
    local memory_limit="${PHP_MEMORY_LIMIT:-512M}"
    local permalink_structure="/%postname%/"

    log_info "Creating site: $site_name..."

    # 1. Create site directory
    local site_dir
    site_dir=$(create_site_directory "$site_name" "$domain" "$PROJECT_ROOT") || {
        log_error "Failed to create site directory"
        return 1
    }

    # 2. Add to configuration
    add_site_to_config_full "$site_name" "$domain" "$php_version" "$db_name" "$admin_email" "$fresh_install" \
        "$remote_server" "$ftp_host" "$ftp_user" "$ftp_pass" "$ftp_path" || {
        log_error "Failed to update configuration"
        return 1
    }

    # 3. Regenerate docker-compose.yml
    if command -v docker compose &> /dev/null && [[ -f "$DOCKER_COMPOSE_FILE" ]]; then
        log_info "Checking Docker setup..."
    fi

    # 4. Create Nginx configuration
    if declare -f generate_nginx_config &> /dev/null; then
        generate_nginx_config "$site_name" "$domain" "$PROJECT_ROOT" "$CONFIG_DIR" "$php_version" "$WWW_DIR" || \
            log_warn "Failed to generate Nginx config"
    fi

    # 4b. Reload Nginx to load new configuration
    if [[ -f "$DOCKER_COMPOSE_FILE" ]] && command -v docker compose &> /dev/null; then
        log_info "Reloading Nginx configuration..."
        if docker compose -f "$DOCKER_COMPOSE_FILE" exec -T nginx nginx -s reload 2>/dev/null; then
            log_success "Nginx reloaded successfully"
        else
            log_warn "Could not reload Nginx. Run: docker compose exec nginx nginx -s reload"
        fi
    fi

    # 5. Create database if MySQL is running
    if [[ -f "$DOCKER_COMPOSE_FILE" ]] && command -v docker compose &> /dev/null; then
        log_info "Creating database..."
        if declare -f create_database_mysql &> /dev/null; then
            create_database_mysql "$db_name" "$db_user" "$db_pass" "localhost" "$DOCKER_COMPOSE_FILE" "mysql" || \
                log_warn "Could not create database automatically. Run 'fb start' first, then try again."
        fi
    else
        log_warn "Docker or docker-compose.yml not found. Skip database creation."
    fi
 
    # 6. Download WordPress
    if check_wp_available "$DOCKER_COMPOSE_FILE" "$php_version" || check_download_tools_available "$DOCKER_COMPOSE_FILE" "$php_version"; then
        log_info "Downloading WordPress..."
        if declare -f download_wordpress &> /dev/null; then
            download_wordpress "$site_dir" "latest" "$DOCKER_COMPOSE_FILE" "$php_version" || \
                log_warn "Failed to download WordPress"
        fi

        # 7. Generate wp-config.php
        if declare -f create_wp_config &> /dev/null; then
            create_wp_config "$site_dir" "$db_name" "$db_user" "$db_pass" "mysql" || \
                log_warn "Failed to generate wp-config.php"
        fi

        # 8. Install WordPress via WP-CLI (if available and Docker running)
        if check_wp_available "$DOCKER_COMPOSE_FILE" "$php_version"; then
            log_info "Installing WordPress..."
            if declare -f install_wordpress &> /dev/null; then
                install_wordpress "$site_name" "https://$domain" "$admin_user" "$admin_pass" "$admin_email" "$site_dir" "$DOCKER_COMPOSE_FILE" "$php_version" || \
                    log_warn "WordPress installation will complete when containers are running"
            fi
        fi

        # 9. Install theme
        if declare -f install_theme_from_config &> /dev/null; then
            log_info "Installing theme: $theme..."
            install_theme_from_config "$SITES_CONFIG" "$site_name" "$site_dir" "$DOCKER_COMPOSE_FILE" "$php_version" || \
                log_warn "Failed to install theme"
        fi

        # 10. Activate theme
        if declare -f activate_theme_from_config &> /dev/null; then
            activate_theme_from_config "$SITES_CONFIG" "$site_name" "$site_dir" || \
                log_warn "Failed to activate theme (may need manual activation)"
        fi

        # 11. Install plugins
        if declare -f install_plugin &> /dev/null; then
            log_info "Installing configured plugins..."

            # Extract plugin info with jq (handles both URL and slug)
            local plugin_count=$(jq '.global.plugins | length' "$SITES_CONFIG" 2>/dev/null || echo 0)

            if [[ $plugin_count -gt 0 ]]; then
                for ((i=0; i<plugin_count; i++)); do
                    local plugin_slug=$(jq -r ".global.plugins[$i].slug" "$SITES_CONFIG" 2>/dev/null)
                    local plugin_url=$(jq -r ".global.plugins[$i].url // empty" "$SITES_CONFIG" 2>/dev/null)
                    local plugin_active=$(jq -r ".global.plugins[$i].active // true" "$SITES_CONFIG" 2>/dev/null)

                    if [[ -n "$plugin_slug" ]]; then
                        if [[ -n "$plugin_url" ]]; then
                            # Install from URL if provided
                            install_plugin "$plugin_slug" "$site_dir" "$plugin_active" "$plugin_url" || \
                                log_warn "Failed to install plugin: $plugin_slug from $plugin_url"
                        else
                            # Install from WP.org slug
                            install_plugin "$plugin_slug" "$site_dir" "$plugin_active" || \
                                log_warn "Failed to install plugin: $plugin_slug"
                        fi
                    fi
                done
            fi
        fi

        # 11b. Activate configured plugins
        if declare -f activate_site_plugins_from_config &> /dev/null; then
            activate_site_plugins_from_config "$SITES_CONFIG" "$site_dir" || \
                log_warn "Failed to activate plugins (may need manual activation)"
        fi

        # 12. Configure permalink structure
        if declare -f set_permalink_structure &> /dev/null; then
            local permalink_structure=$(jq -r '.wordpress.permalinkStructure // "/%postname%/"' "$SITES_CONFIG" 2>/dev/null)
            set_permalink_structure "$site_dir" "$permalink_structure" "$DOCKER_COMPOSE_FILE" "$php_version" || \
                log_warn "Failed to configure permalink structure (may need manual setup)"
        fi
    else
        log_warn "Neither WP-CLI nor wget/curl available. WordPress setup will be manual."
    fi

    # Display summary
    if declare -f display_site_summary &> /dev/null; then
        display_site_summary "$site_name" "$domain" "$php_version" "$db_name" "$admin_user" "$admin_pass" "$admin_email" "$theme"
    else
        printf "\n${GREEN}✓ Site '$site_name' created successfully!${NC}\n\n"
        printf "${BOLD}Site Details:${NC}\n"
        printf "  Name:        $site_name\n"
        printf "  Domain:      $domain\n"
        printf "  PHP:         $php_version\n"
        printf "  Database:    $db_name\n"
        printf "\n${BOLD}Next Steps:${NC}\n"
        printf "  1. Run: ${CYAN}fb start${NC}\n"
        printf "  2. Visit: ${CYAN}https://$domain${NC}\n\n"
    fi


}

cmd_site_list() {
    load_config "$SITES_CONFIG" || return 1

    log_section "Configured Sites"

    local sites=$(get_all_sites)

    if [[ -z "$sites" ]]; then
        log_warn "No sites configured"
        log_info "Add your first site with: fb site add"
        return
    fi

    printf "\n${BOLD}Name${NC}\t${BOLD}Domain${NC}\t\t${BOLD}PHP${NC}\n"
    printf "────────────────────────────────────────────\n"

    while IFS= read -r site_name; do
        local site_config=$(get_site "$site_name")
        local domain=$(echo "$site_config" | jq -r '.domain')
        local php=$(echo "$site_config" | jq -r '.phpVersion // "8.1"')
        printf "$site_name\t$domain\t$php\n"
    done <<< "$sites"

    printf "\n"
}

cmd_site_info() {
    load_config "$SITES_CONFIG" || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    log_section "Site Information: $site_name"

    local site_config=$(get_site "$site_name")
    echo "$site_config" | jq '.'
}

cmd_site_remove() {
    load_config "$SITES_CONFIG" || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    if ! prompt_confirm "Remove site '$site_name'?"; then
        log_info "Cancelled"
        return
    fi

    log_info "Removing site '$site_name'..."

    # Extract database credentials from config
    log_debug "Extracting database credentials for site '$site_name'..."
    local db_name=$(jq -r ".sites.\"$site_name\".dbName // empty" "$SITES_CONFIG")
    local db_user=$(jq -r ".sites.\"$site_name\".dbUser // \"root\"" "$SITES_CONFIG")
    local db_pass=$(jq -r ".sites.\"$site_name\".dbPassword // \"Admin123\"" "$SITES_CONFIG")

    if [[ -n "$db_name" ]]; then
        log_info "Database name: $db_name"
        log_debug "Database user: $db_user"
    else
        log_warn "No database name found for site '$site_name'"
    fi

    # Remove database if it exists
    if [[ -n "$db_name" ]]; then
        log_info "Removing database: $db_name..."
        drop_database "$db_name" "$db_user" "$db_pass" "$DOCKER_COMPOSE_FILE" "mysql"
        if [[ $? -eq 0 ]]; then
            log_success "Database removed successfully"
        else
            log_warn "Failed to remove database (it may not exist)"
        fi
    fi

    # Remove from config
    log_info "Removing site from configuration..."
    local temp_file=$(mktemp)
    jq 'if (.sites | type) == "array" then
        del(.sites[] | select(.name == "'$site_name'"))
    else
        del(.sites."'$site_name'")
    end' "$SITES_CONFIG" > "$temp_file"
    mv "$temp_file" "$SITES_CONFIG"
    log_success "Site removed from configuration"

    # Remove directory
    log_info "Removing site directory: $WWW_DIR/$site_name..."
    rm -rf "$WWW_DIR/$site_name"
    log_debug "Site directory removed"

    # Remove Nginx configuration
    log_info "Removing Nginx configuration..."
    rm -rf "$NGINX_SITES_ENABLED/$site_name.conf"
    log_debug "Nginx config removed"

    # Remove log files
    log_info "Removing log files..."
    rm -rf "$NGINX_DIR/logs/${site_name}_error.log"
    rm -rf "$NGINX_DIR/logs/${site_name}_access.log"
    log_debug "Log files removed"

    log_success "Site '$site_name' removed successfully"
}

cmd_site_configure() {
    load_config "$SITES_CONFIG" || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    log_section "Configure Site: $site_name"
    log_info "Opening configuration in editor..."

    ${EDITOR:-nano} "$SITES_CONFIG"
}
