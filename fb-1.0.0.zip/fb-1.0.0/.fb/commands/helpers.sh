#!/bin/bash

################################################################################
# Helper functions used across all commands
# Provides common utilities, site management, and utility functions
################################################################################

# Get all sites (handles both array and object formats)
get_all_sites() {
    jq -r 'if (.sites | type) == "array" then
        .sites[]?.name
    else
        .sites | keys[]
    end' "$SITES_CONFIG" 2>/dev/null
}

# Get specific site configuration
get_site() {
    local site_name="$1"

    jq 'if (.sites | type) == "array" then
        .sites[] | select(.name == "'$site_name'")
    else
        .sites."'$site_name'"
    end' "$SITES_CONFIG" 2>/dev/null
}

# Check if site exists
site_exists() {
    local site_name="$1"
    local site=$(get_site "$site_name")
    [[ -n "$site" ]] && [[ "$site" != "null" ]]
}

# Check if wp-cli is available (Docker container or local)
check_wp_available() {
    local docker_compose_file="${1:-}"
    local php_version="${2:-8.1}"
    local php_service=$(get_php_service "$php_version")

    # Try Docker first if docker-compose file exists

    if [[ -n "$docker_compose_file" ]] && [[ -f "$docker_compose_file" ]] && command -v docker compose &> /dev/null; then
        if docker compose -f "$docker_compose_file" exec -T "$php_service" which wp &> /dev/null 2>&1; then
            return 0
        fi
    fi

    # Fallback to local wp-cli
    if command -v wp &> /dev/null; then
        return 0
    fi

    return 1
}

# Check if wget or curl is available (for fallback downloads)
check_download_tools_available() {
    if command -v wget &> /dev/null || command -v curl &> /dev/null; then
        return 0
    fi

    # Try docker container as fallback
    local docker_compose_file="${1:-}"
    local php_version="${2:-8.1}"
    local php_service=$(get_php_service "$php_version")

    if [[ -n "$docker_compose_file" ]] && [[ -f "$docker_compose_file" ]] && command -v docker compose &> /dev/null; then
        if docker compose -f "$docker_compose_file" exec -T "$php_service" which wget &> /dev/null 2>&1 || \
           docker compose -f "$docker_compose_file" exec -T "$php_service" which curl &> /dev/null 2>&1; then
            return 0
        fi
    fi

    return 1
}

# Verify site directory exists
verify_site_directory() {
    local site_name="$1"
    local site_dir="$WWW_DIR/$site_name"

    if [[ ! -d "$site_dir" ]]; then
        log_error "Site directory not found: $site_dir"
        return 1
    fi

    return 0
}

# Get site from config with error handling
get_site_config() {
    local site_name="$1"

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found in configuration"
        return 1
    fi

    get_site "$site_name"
}

# Ensure site directory exists
ensure_site_directory() {
    local site_dir="$1"

    if [[ ! -d "$site_dir" ]]; then
        mkdir -p "$site_dir"
        log_info "Created site directory: $site_dir"
    fi
}

# Get PHP service container name based on PHP version
# Usage: get_php_service "7.4" or get_php_service "$php_version"
get_php_service() {
    local php_version="${1:-8.1}"

    if [[ "$php_version" == "7.4" ]] || [[ "$php_version" == "7.3" ]]; then
        echo "php7"
    else
        echo "php"
    fi
}

# Get PHP container for site
# Usage: get_php_container_for_site "site_name"
get_php_container_for_site() {
    local site_name="$1"
    local site_config=$(get_site "$site_name")
    local php_version=$(echo "$site_config" | jq -r '.phpVersion // "8.1"')

    # Use the generic get_php_service function
    get_php_service "$php_version"
}

# Export common variables for use in commands
export_command_variables() {
    export PROJECT_ROOT
    export CONFIG_DIR
    export SITES_CONFIG
    export ENV_FILE
    export DOCKER_COMPOSE_FILE
    export WWW_DIR
    export BACKUPS_DIR
    export SCRIPTS_DIR
    export NGINX_DIR
    export NGINX_SITES_ENABLED
    export CERT_DIR
    export LIB_DIR
}
