#!/bin/bash

################################################################################
# COMMAND: INIT
# Initializes new fb project with Docker setup
################################################################################

cmd_init() {
    log_section "Initialize fb Project"

    # Check if already initialized
    if [[ -f "$SITES_CONFIG" ]]; then
        log_warn "Project already initialized"
        if ! prompt_confirm "Overwrite existing configuration?"; then
            log_info "Initialization cancelled"
            return 0
        fi
    fi

    # Ensure .env exists
    if [[ ! -f "$ENV_FILE" ]]; then
        if [[ -f "${ENV_FILE}.example" ]]; then
            cp "${ENV_FILE}.example" "$ENV_FILE"
            log_success "Created .env from template"
        else
            create_default_env "$ENV_FILE"
        fi
    fi

    # Ensure directories exist
    mkdir -p "$WWW_DIR" "$BACKUPS_DIR" "$NGINX_SITES_ENABLED" "$CERT_DIR"

    log_info "Enter project details (press Enter for defaults):"
    printf "\n"

    local project_name=$(prompt "Project name" "fb project")
    local mysql_version=$(prompt "MySQL version" "5.7")
    local node_version=$(prompt "Node.js version" "20")
    local memory_limit=$(prompt "PHP memory limit" "512M")
    local upload_max_size=$(prompt "PHP upload max size" "200M")

    # Create initial config
    create_initial_config "$SITES_CONFIG" "$project_name" "$mysql_version" "$node_version"

    # Generate all Docker and configuration files dynamically
    log_info "Generating Docker and configuration files..."
    generate_all_files "$PROJECT_ROOT" "$mysql_version" "$node_version" "$memory_limit" "$upload_max_size" "$CONFIG_DIR" "$WWW_DIR" || {
        log_error "Failed to generate configuration files"
        return 1
    }

    log_success "Project initialized successfully!"

    printf "\n"
    log_info "Generated files:"
    log_info "  • $CONFIG_DIR/docker-compose.yml"
    log_info "  • $CONFIG_DIR/dockerfiles/php.dockerfile"
    log_info "  • $CONFIG_DIR/dockerfiles/nginx.dockerfile"
    log_info "  • $CONFIG_DIR/nginx/nginx.conf"
    log_info "  • $CONFIG_DIR/nginx/sites-enabled/default.conf"
    log_info "  • $CONFIG_DIR/php/php.ini"
    log_info "  • $CONFIG_DIR/php/www.conf"
    log_info "  • $CONFIG_DIR/mysql/my.cnf"

    printf "\n"
    log_info "Next steps:"
    log_info "  1. Review generated files in $CONFIG_DIR"
    log_info "  2. Run: fb start"
    log_info "  3. Run: fb site add mysite"

    printf "\n"
    log_info "To add your first site, run: fb site add mysite"
}
