#!/bin/bash

################################################################################
# COMMAND: DB
# Database operations (backup, restore, shell, optimize)
################################################################################

cmd_db() {
    if [[ $# -eq 0 ]]; then
        printf "${CYAN}fb db${NC} - Database operations\n"
        printf "\n${BLUE}USAGE:${NC}\n"
        printf "    fb db [SUBCOMMAND] [SITE_NAME]\n"
        printf "\n${BLUE}SUBCOMMANDS:${NC}\n"
        printf "    backup [NAME]       Backup database\n"
        printf "    restore [FILE]      Restore from backup\n"
        printf "    shell [NAME]        Connect to MySQL shell\n"
        printf "    optimize [NAME]     Optimize database\n"
        printf "\n"
        return
    fi

    local subcommand="$1"
    shift || true

    case "$subcommand" in
        backup) cmd_db_backup "$@" ;;
        restore) cmd_db_restore "$@" ;;
        shell) cmd_db_shell "$@" ;;
        optimize) cmd_db_optimize "$@" ;;
        *)
            log_error "Unknown subcommand: $subcommand"
            return 1
            ;;
    esac
}

cmd_db_backup() {
    check_docker_compose || return 1
    load_config "$SITES_CONFIG" || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    load_env "$ENV_FILE"
    mkdir -p "$BACKUPS_DIR"

    # Get database name from site config
    local site_config=$(get_site "$site_name")
    local db_name=$(echo "$site_config" | jq -r '.dbName')
    local db_user=$(echo "$site_config" | jq -r '.dbUser')
    local db_pass=$(echo "$site_config" | jq -r '.dbPassword')

    local backup_file="$BACKUPS_DIR/${site_name}_$(date +%Y%m%d_%H%M%S).sql"
    local backup_file_prj="$WWW_DIR/${site_name}/${site_name}_$(date +%Y%m%d_%H%M%S).sql"

    log_info "Backing up database for: $site_name..."

    if declare -f export_database &> /dev/null; then
        export_database "$db_name" "$backup_file" "$db_user" "$db_pass" "$DOCKER_COMPOSE_FILE" "mysql"
        export_database "$db_name" "$backup_file_prj" "$db_user" "$db_pass" "$DOCKER_COMPOSE_FILE" "mysql"
    else
        log_error "export_database function not found in database-manager.sh"
        return 1
    fi
}

cmd_db_restore() {
    check_docker_compose || return 1
    load_config "$SITES_CONFIG" || return 1

    local backup_file="${1:-}"
    if [[ -z "$backup_file" ]]; then
        backup_file=$(prompt "Backup file path")
    fi

    if [[ ! -f "$backup_file" ]]; then
        log_error "Backup file not found: $backup_file"
        return 1
    fi

    local site_name=$(prompt "Site name")

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    if ! prompt_confirm "Restore database? This will overwrite existing data"; then
        log_info "Cancelled"
        return
    fi

    load_env "$ENV_FILE"

    # Get database credentials from site config
    local site_config=$(get_site "$site_name")
    local db_name=$(echo "$site_config" | jq -r '.dbName')
    local db_user=$(echo "$site_config" | jq -r '.dbUser')
    local db_pass=$(echo "$site_config" | jq -r '.dbPassword')
    local domain=$(echo "$site_config" | jq -r '.domain')
    local remote_domain=$(echo "$site_config" | jq -r '.remoteServer // empty')
    local site_dir="$WWW_DIR/$site_name"

    log_info "Restoring database from: $backup_file..."

    if declare -f import_database &> /dev/null; then
        import_database "$db_name" "$backup_file" "$db_user" "$db_pass" "$DOCKER_COMPOSE_FILE" "mysql" || {
            log_error "Database restore failed"
            return 1
        }
    else
        log_error "import_database function not found in database-manager.sh"
        return 1
    fi

    # Replace URLs if remote domain is configured
    if [[ -n "$remote_domain" ]] && [[ "$remote_domain" != "null" ]]; then
        log_info "Replacing remote domain with local domain..."

        # Convert domain to URL format
        local old_url="https://$remote_domain"
        local new_url="https://$domain"
        local container_path="$WWW_DIR/$site_name"

        # Get PHP container based on site config
        local php_version=$(echo "$site_config" | jq -r '.phpVersion // "8.1"')
        local php_container=$(get_php_service "$php_version")

        if declare -f replace_url_in_database &> /dev/null; then
            replace_url_in_database "$old_url" "$new_url" "$container_path" "$DOCKER_COMPOSE_FILE" "$php_container"
        else
            log_warn "replace_url_in_database function not found"
        fi
    fi

    log_success "Database restore completed successfully"
}

cmd_db_shell() {
    check_docker_compose || return 1
    load_config "$SITES_CONFIG" || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    load_env "$ENV_FILE"

    # Get database credentials from site config
    local site_config=$(get_site "$site_name")
    local db_name=$(echo "$site_config" | jq -r '.dbName')
    local db_user=$(echo "$site_config" | jq -r '.dbUser')
    local db_pass=$(echo "$site_config" | jq -r '.dbPassword')

    log_info "Connecting to MySQL shell for: $site_name..."

    docker_exec_interactive "$DOCKER_COMPOSE_FILE" "mysql" mysql \
        -u "$db_user" \
        -p"$db_pass" \
        "$db_name"
}

cmd_db_optimize() {
    check_docker_compose || return 1
    load_config "$SITES_CONFIG" || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    load_env "$ENV_FILE"

    # Get database credentials from site config
    local site_config=$(get_site "$site_name")
    local db_name=$(echo "$site_config" | jq -r '.dbName')
    local db_user=$(echo "$site_config" | jq -r '.dbUser')
    local db_pass=$(echo "$site_config" | jq -r '.dbPassword')

    log_info "Optimizing database: $site_name..."

    if declare -f optimize_database &> /dev/null; then
        optimize_database "$db_name" "$db_user" "$db_pass" "$DOCKER_COMPOSE_FILE" "mysql"
    else
        log_error "optimize_database function not found in database-manager.sh"
        return 1
    fi
}
