#!/bin/bash

################################################################################
# COMMAND: START / STOP
# Manages Docker container lifecycle
################################################################################

cmd_start() {
    check_docker || return 1
    check_docker_compose || return 1

    log_section "Starting Docker Containers"

    # Generate docker-compose.yml if needed
    if [[ ! -f "$DOCKER_COMPOSE_FILE" ]]; then
        log_info "Generating docker-compose.yml..."
        # Generate with relative paths for portability
        generate_docker_compose "$PROJECT_ROOT" "$CONFIG_DIR" "$WWW_DIR" "." "8.1" "5.7" "20" "$DOCKER_COMPOSE_FILE" || return 1
    fi

    docker compose -f "$DOCKER_COMPOSE_FILE" up -d || {
        log_error "Failed to start containers"
        return 1
    }

    log_success "Containers started"
    log_info ""
    log_info "Services available:"
    log_info "  WordPress: https://localhost"
    log_info "  PHPMyAdmin: http://localhost:8080"
    log_info "  Mailhog: http://localhost:8025"
}

cmd_restart() {
  cmd_stop
  cmd_start
}

cmd_stop() {
    check_docker_compose || return 1

    log_section "Stopping Docker Containers"

    if [[ ! -f "$DOCKER_COMPOSE_FILE" ]]; then
        log_error "docker-compose.yml not found"
        return 1
    fi

    docker compose -f "$DOCKER_COMPOSE_FILE" down || {
        log_error "Failed to stop containers"
        return 1
    }

    log_success "Containers stopped"
}
