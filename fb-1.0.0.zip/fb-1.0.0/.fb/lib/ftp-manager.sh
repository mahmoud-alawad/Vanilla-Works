#!/bin/bash

################################################################################
# FTP Manager Library - Download media from remote FTP server
################################################################################

################################################################################
# DOWNLOAD MEDIA FROM FTP
################################################################################

# Download WordPress media from remote FTP server
download_media_from_ftp() {
    local site_name="$1"
    local site_dir="$2"
    local ftp_host="$3"
    local ftp_user="$4"
    local ftp_password="$5"
    local ftp_path="${6:-/wp-content/uploads}"

    log_info "Downloading media from FTP for site: $site_name..."
    log_debug "  FTP Host: $ftp_host"
    log_debug "  FTP User: $ftp_user"
    log_debug "  FTP Path: $ftp_path"

    # Check if site directory exists
    if [[ ! -d "$site_dir" ]]; then
        log_error "Site directory not found: $site_dir"
        return 1
    fi

    # Create uploads directory if it doesn't exist
    local uploads_dir="$site_dir/wp-content/uploads"
    mkdir -p "$uploads_dir" || {
        log_error "Failed to create uploads directory: $uploads_dir"
        return 1
    }

    # Try using lftp first (more reliable for FTP)
    if command -v lftp &> /dev/null; then
        log_info "Using lftp for FTP download..."
        if download_media_lftp "$ftp_host" "$ftp_user" "$ftp_password" "$ftp_path" "$uploads_dir"; then
            log_success "Media downloaded successfully via lftp"
            return 0
        fi
    fi

    # Fallback to ftp command
    if command -v ftp &> /dev/null; then
        log_info "Using ftp for download..."
        if download_media_ftp "$ftp_host" "$ftp_user" "$ftp_password" "$ftp_path" "$uploads_dir"; then
            log_success "Media downloaded successfully via ftp"
            return 0
        fi
    fi

    # Fallback to wget with FTP URL
    if command -v wget &> /dev/null; then
        log_info "Using wget for FTP download..."
        if download_media_wget "$ftp_host" "$ftp_user" "$ftp_password" "$ftp_path" "$uploads_dir"; then
            log_success "Media downloaded successfully via wget"
            return 0
        fi
    fi

    log_error "No FTP tool available. Install lftp, ftp, or wget"
    return 1
}

# Download media using lftp (preferred method)
download_media_lftp() {
    local ftp_host="$1"
    local ftp_user="$2"
    local ftp_password="$3"
    local ftp_path="$4"
    local local_dir="$5"

    # Create lftp script
    local lftp_script="/tmp/lftp_sync_$$.sh"
    cat > "$lftp_script" << EOF
#!/bin/bash
lftp -e "
set ftp:ssl-allow no
set ftp:passive-mode yes
open -u $ftp_user,$ftp_password $ftp_host
mirror --continue --delete --no-permissions $ftp_path $local_dir
quit
" 2>&1
EOF

    chmod +x "$lftp_script"

    if bash "$lftp_script"; then
        rm -f "$lftp_script"
        return 0
    else
        rm -f "$lftp_script"
        return 1
    fi
}

# Download media using standard ftp command
download_media_ftp() {
    local ftp_host="$1"
    local ftp_user="$2"
    local ftp_password="$3"
    local ftp_path="$4"
    local local_dir="$5"

    # Create ftp script
    local ftp_script="/tmp/ftp_sync_$$.txt"
    cat > "$ftp_script" << EOF
open $ftp_host
user $ftp_user $ftp_password
binary
cd $ftp_path
lcd $local_dir
prompt off
mget *
quit
EOF

    if ftp -n < "$ftp_script" > /dev/null 2>&1; then
        rm -f "$ftp_script"
        # Recursively download subdirectories
        download_ftp_recursive "$ftp_host" "$ftp_user" "$ftp_password" "$ftp_path" "$local_dir"
        return 0
    else
        rm -f "$ftp_script"
        return 1
    fi
}

# Recursively download FTP directories
download_ftp_recursive() {
    local ftp_host="$1"
    local ftp_user="$2"
    local ftp_password="$3"
    local ftp_path="$4"
    local local_dir="$5"

    # Create ftp script to list directories
    local ftp_list="/tmp/ftp_list_$$.txt"
    cat > "$ftp_list" << EOF
open $ftp_host
user $ftp_user $ftp_password
cd $ftp_path
ls
quit
EOF

    # This is a simplified recursive download - FTP doesn't support recursive well
    # For production, lftp is recommended
    rm -f "$ftp_list"
}

# Download media using wget with FTP URL
download_media_wget() {
    local ftp_host="$1"
    local ftp_user="$2"
    local ftp_password="$3"
    local ftp_path="$4"
    local local_dir="$5"

    local ftp_url="ftp://${ftp_user}:${ftp_password}@${ftp_host}${ftp_path}"

    log_debug "FTP URL: ftp://${ftp_user}:***@${ftp_host}${ftp_path}"

    if wget -r --ftp-user="$ftp_user" --ftp-password="$ftp_password" \
             --directory-prefix="$local_dir" \
             "ftp://$ftp_host$ftp_path" 2>&1 | grep -i "error\|failed"; then
        return 1
    else
        return 0
    fi
}

################################################################################
# SYNC MEDIA AND DATABASE
################################################################################

# Full sync: download database dump and media
sync_site_from_remote() {
    local site_name="$1"
    local site_dir="$2"
    local ftp_credentials_json="$3"
    local config_file="$4"

    log_section "Syncing site: $site_name"

    # Parse FTP credentials
    local ftp_host=$(echo "$ftp_credentials_json" | jq -r '.host // empty')
    local ftp_user=$(echo "$ftp_credentials_json" | jq -r '.user // empty')
    local ftp_password=$(echo "$ftp_credentials_json" | jq -r '.password // empty')
    local ftp_media_path=$(echo "$ftp_credentials_json" | jq -r '.mediaPath // "/wp-content/uploads"')
    local ftp_db_dump=$(echo "$ftp_credentials_json" | jq -r '.databaseDumpPath // empty')

    # Validate credentials
    if [[ -z "$ftp_host" ]] || [[ -z "$ftp_user" ]] || [[ -z "$ftp_password" ]]; then
        log_error "Incomplete FTP credentials"
        return 1
    fi

    log_info "FTP Host: $ftp_host"
    log_info "FTP User: $ftp_user"

    # Download media
    if download_media_from_ftp "$site_name" "$site_dir" "$ftp_host" "$ftp_user" "$ftp_password" "$ftp_media_path"; then
        log_success "Media synced successfully"
    else
        log_warn "Failed to sync media"
    fi

    # Download database dump if path is provided
    if [[ -n "$ftp_db_dump" ]]; then
        log_info "Downloading database dump..."
        if download_database_dump "$site_name" "$ftp_host" "$ftp_user" "$ftp_password" "$ftp_db_dump"; then
            log_success "Database dump downloaded"
        else
            log_warn "Failed to download database dump"
        fi
    fi

    return 0
}

# Download database dump from FTP
download_database_dump() {
    local site_name="$1"
    local ftp_host="$2"
    local ftp_user="$3"
    local ftp_password="$4"
    local ftp_db_path="$5"

    local backup_dir=".fb/backups"
    mkdir -p "$backup_dir"

    local dump_file="$backup_dir/${site_name}_remote_dump.sql.gz"

    log_info "Downloading database dump from: $ftp_db_path"

    # Try wget
    if command -v wget &> /dev/null; then
        if wget -q -O "$dump_file" \
            --user="$ftp_user" \
            --password="$ftp_password" \
            "ftp://$ftp_host$ftp_db_path" 2>/dev/null; then
            log_success "Database dump downloaded to: $dump_file"
            return 0
        fi
    fi

    # Try curl
    if command -v curl &> /dev/null; then
        if curl -s -o "$dump_file" \
            -u "$ftp_user:$ftp_password" \
            "ftp://$ftp_host$ftp_db_path" 2>/dev/null; then
            log_success "Database dump downloaded to: $dump_file"
            return 0
        fi
    fi

    log_error "Failed to download database dump"
    return 1
}
