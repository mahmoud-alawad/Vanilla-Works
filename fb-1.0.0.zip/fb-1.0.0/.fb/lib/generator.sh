#!/bin/bash

################################################################################
# Generator Library - Generate docker-compose.yml and Dockerfiles dynamically
################################################################################


################################################################################
# GENERATE DOCKER-COMPOSE.YML
################################################################################

generate_docker_compose() {
    local project_root="$1"
    local config_dir="$2"
    local www_dir="$3"
    local context_path="$4"
    local mysql_version="${5:-5.7}"
    local node_version="${6:-20}"
    local output_file="${7:-docker-compose.yml}"

    log_info "Generating docker-compose.yml (PHP 8.1 + 7.4)..."
    log_debug "Paths: config_dir=$config_dir, www_dir=$www_dir, context_path=$context_path"

    cat > "$output_file" << DOCKER_COMPOSE
version: '3.8'

volumes:
  db-data:
    driver: local

networks:
  dev:
    driver: bridge

services:
  mysql:
    image: mysql:${mysql_version}
    container_name: mysql
    restart: unless-stopped
    tty: true
    ports:
      - "\${MYSQL_PORT:-3306}:3306"
    environment:
      MYSQL_ROOT_PASSWORD: \${MYSQL_ROOT_PASSWORD:-Admin123}
      SERVICE_TAGS: development
      SERVICE_NAME: mysql
    volumes:
      - db-data:/var/lib/mysql
      - ${config_dir}/mysql/my.cnf:/etc/mysql/conf.d/my.cnf
    networks:
      - dev
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
      interval: 10s
      timeout: 5s
      retries: 5

  php:
    container_name: php
    build:
      context: ${context_path}
      dockerfile: ${config_dir}/dockerfiles/php.dockerfile
      args:
        - PHP_VERSION=8.1
        - UID=\${UID:-1000}
        - GID=\${GID:-1000}
        - WWW_DIR=${www_dir}
    restart: unless-stopped
    depends_on:
      mysql:
        condition: service_healthy
    volumes:
      - ${config_dir}/php/php.ini:/usr/local/etc/php/php.ini
      - ${www_dir}:${www_dir}:delegated
    ports:
      - "\${PHP_PORT:-9000}:9000"
    networks:
      - dev
    environment:
      PHP_VERSION: 8.1
      MYSQL_HOST: mysql
      MYSQL_PORT: 3306
      MYSQL_ROOT_PASSWORD: \${MYSQL_ROOT_PASSWORD:-Admin123}
      WWW_DIR: ${www_dir}

  php7:
    container_name: php7
    build:
      context: ${context_path}
      dockerfile: ${config_dir}/dockerfiles/php7.dockerfile
      args:
        - PHP_VERSION=7.4
        - UID=\${UID:-1000}
        - GID=\${GID:-1000}
        - WWW_DIR=${www_dir}
    restart: unless-stopped
    depends_on:
      mysql:
        condition: service_healthy
    volumes:
      - ${config_dir}/php/php.ini:/usr/local/etc/php/php.ini
      - ${www_dir}:${www_dir}:delegated
    ports:
      - "\${PHP7_PORT:-9001}:9000"
    networks:
      - dev
    environment:
      PHP_VERSION: 7.4
      MYSQL_HOST: mysql
      MYSQL_PORT: 3306
      MYSQL_ROOT_PASSWORD: \${MYSQL_ROOT_PASSWORD:-Admin123}
      WWW_DIR: ${www_dir}

  nginx:
    build:
      context: ${context_path}
      dockerfile: ${config_dir}/dockerfiles/nginx.dockerfile
      args:
        - UID=\${UID:-1000}
        - GID=\${GID:-1000}
    ports:
      - "\${NGINX_PORT:-80}:80"
      - "\${NGINX_HTTPS_PORT:-443}:443"
    restart: unless-stopped
    volumes:
      - ${www_dir}:${www_dir}:delegated
      - ${config_dir}/nginx/logs/:/var/log/nginx/
      - ${config_dir}/nginx/sites-enabled/:/etc/nginx/conf.d
      - ${config_dir}/cert/:/etc/nginx/certs
      - ${config_dir}/nginx/nginx.conf:/etc/nginx/nginx.conf
    environment:
      WWW_DIR: ${www_dir}
    depends_on:
      mysql:
        condition: service_healthy
      php:
        condition: service_started
      php7:
        condition: service_started
    networks:
      - dev

  node:
    image: node:${node_version}
    working_dir: ${www_dir}
    user: \${UID:-1000}:\${UID:-1000}
    networks:
      - dev
    environment:
      HOST: 0.0.0.0
      WWW_DIR: ${www_dir}
    volumes:
      - ${www_dir}:${www_dir}:delegated
    ports:
      - "\${NODE_PORT:-5173}:5173"
    command: node --version

  phpmyadmin:
    depends_on:
      mysql:
        condition: service_healthy
    image: phpmyadmin/phpmyadmin
    restart: always
    ports:
      - '\${PHPMYADMIN_PORT:-8080}:80'
    environment:
      PMA_HOST: mysql
      MYSQL_ROOT_PASSWORD: \${MYSQL_ROOT_PASSWORD:-Admin123}
      PMA_USER: root
      PMA_PASSWORD: \${MYSQL_ROOT_PASSWORD:-Admin123}
      MEMORY_LIMIT: 1000M
      UPLOAD_LIMIT: 1000M
    networks:
      - dev

  mailhog:
    image: mailhog/mailhog:latest
    restart: unless-stopped
    ports:
      - "\${MAILHOG_SMTP_PORT:-1025}:1025"
      - "\${MAILHOG_UI_PORT:-8025}:8025"
    networks:
      - dev
DOCKER_COMPOSE

    log_success "Generated docker-compose.yml: $output_file"
}

################################################################################
# GENERATE PHP DOCKERFILE
################################################################################

generate_php_dockerfile() {
    local php_version="${1:-8.1}"
    local output_file="${2:-.fb/dockerfiles/php.dockerfile}"

    log_info "Generating PHP Dockerfile for version $php_version..."

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << PHP_DOCKERFILE
ARG PHP_VERSION=${php_version}
FROM php:\${PHP_VERSION}-fpm-alpine

ARG UID
ARG GID
ARG PHP_VERSION
ARG WWW_DIR=/var/www/html

ENV UID=\${UID}
ENV GID=\${GID}
ENV USER=wordpress
ENV PHP_MEMORY_LIMIT=512M
ENV WWW_DIR=\${WWW_DIR}

WORKDIR \${WWW_DIR}

RUN mkdir -p \${WWW_DIR} /var/log/

# Install base packages
RUN apk add --no-cache \\
    bash \\
    jq \\
    curl \\
    wget \\
    libjpeg-turbo-dev \\
    libpng-dev \\
    freetype-dev \\
    openssl \\
    libzip-dev \\
    git

# Setup PHP extensions
RUN apk add --update --no-cache --virtual .build-deps \\
    freetype-dev \\
    gmp-dev \\
    bash \\
    curl \\
    icu-dev \\
    openssl \\
    libintl \\
    libjpeg-turbo-dev \\
    libpng-dev \\
    libxml2-dev \\
    libzip-dev \\
    linux-headers \\
    postgresql-dev \\
    \$PHPIZE_DEPS

RUN docker-php-ext-configure gd \\
    --with-freetype=/usr/include/ \\
    --with-jpeg=/usr/include/

RUN docker-php-ext-install -j"\$(getconf _NPROCESSORS_ONLN)" \\
    bcmath \\
    gd \\
    gmp \\
    intl \\
    mysqli \\
    opcache \\
    pdo_mysql \\
    pdo_pgsql \\
    pcntl \\
    sockets \\
    zip

RUN docker-php-ext-enable pdo_mysql gd intl sockets zip

# Install WP-CLI
RUN curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar && \\
    chmod +x wp-cli.phar && \\
    mv wp-cli.phar /usr/local/bin/wp

# Install Composer
COPY --from=composer:latest /usr/bin/composer /usr/local/bin/composer

# Install mhsendmail for Mailhog integration
RUN curl -L https://github.com/mailhog/mhsendmail/releases/download/v0.2.0/mhsendmail_linux_amd64 -o /usr/local/bin/mhsendmail && \
    chmod +x /usr/local/bin/mhsendmail

# Remove dialout group (macOS compatibility)
RUN delgroup dialout

# Create WordPress user
RUN addgroup -g \${GID} --system \${USER}
RUN adduser -G \${USER} --system -D -s /bin/sh -u \${UID} \${USER}

# Configure PHP-FPM
RUN sed -i "s/user = www-data/user = \${USER}/g" /usr/local/etc/php-fpm.d/www.conf
RUN sed -i "s/group = www-data/group = \${USER}/g" /usr/local/etc/php-fpm.d/www.conf
RUN echo "php_admin_flag[log_errors] = on" >> /usr/local/etc/php-fpm.d/www.conf

USER \${USER}

CMD ["php-fpm", "-y", "/usr/local/etc/php-fpm.conf", "-R"]
PHP_DOCKERFILE

    log_success "Generated PHP Dockerfile: $output_file"
}

################################################################################
# GENERATE NGINX DOCKERFILE
################################################################################

generate_nginx_dockerfile() {
    local output_file="${1:-.fb/dockerfiles/nginx.dockerfile}"

    log_info "Generating Nginx Dockerfile..."

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << NGINX_DOCKERFILE
FROM nginx:stable-alpine

ARG UID
ARG GID
ARG WWW_DIR=/var/www/html

ENV UID=\${UID}
ENV GID=\${GID}
ENV WWW_DIR=\${WWW_DIR}

# Remove dialout group (macOS compatibility)
RUN delgroup dialout

# Create WordPress user
RUN addgroup -g \${GID} --system wordpress
RUN adduser -G wordpress --system -D -s /bin/sh -u \${UID} wordpress

# Update nginx config to use wordpress user
RUN sed -i "s/user  nginx/user wordpress/g" /etc/nginx/nginx.conf

# Create necessary directories
RUN mkdir -p \${WWW_DIR} /var/log/nginx

EXPOSE 80 443

CMD ["nginx", "-g", "daemon off;"]
NGINX_DOCKERFILE

    log_success "Generated Nginx Dockerfile: $output_file"
}

################################################################################
# GENERATE PHP.INI
################################################################################

generate_php_ini() {
    local memory_limit="${1:-512M}"
    local upload_max_size="${2:-200M}"
    local output_file="${3:-.fb/php/php.ini}"

    log_info "Generating php.ini with memory_limit=$memory_limit, upload_max_size=$upload_max_size..."

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << PHP_INI
; PHP Configuration for WordPress Development

[PHP]
memory_limit = ${memory_limit}
max_execution_time = 300
max_input_time = 300
post_max_size = ${upload_max_size}
upload_max_filesize = ${upload_max_size}
default_charset = "UTF-8"

[Date]
date.timezone = "UTC"

[Mysqli]
mysqli.reconnect = On
mysqli.reconnect_enabled = On

[MySQL]
mysql.reconnect = On

[mysqlnd]
mysqlnd.db_driver = mysqli
mysqlnd.trace_alloc = Off

[Error handling and logging]
display_errors = On
display_startup_errors = On
log_errors = On
error_log = /var/log/php_errors.log

[Session]
session.save_handler = files
session.save_path = /tmp

[opcache]
opcache.enable=1
opcache.memory_consumption=512M
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=10000
opcache.revalidate_freq=2
opcache.validate_timestamps=1

[mail function]
; Use Mailhog SMTP server for email testing in development
SMTP = mailhog
SMTP_PORT = 1025
sendmail_path = "/usr/local/bin/mhsendmail --smtp-addr=mailhog:1025"

PHP_INI

    log_success "Generated php.ini: $output_file"
}

################################################################################
# GENERATE NGINX.CONF
################################################################################

generate_nginx_conf() {
    local output_file="${1:-.fb/nginx/nginx.conf}"

    log_info "Generating nginx.conf..."

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << NGINX_CONF
user wordpress;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    use epoll;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format main '\$remote_addr - \$remote_user [\$time_local] "\$request" '
                    '\$status \$body_bytes_sent "\$http_referer" '
                    '"\$http_user_agent" "\$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 200M;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss application/rss+xml;

    # Include all site configurations
    include /etc/nginx/conf.d/*.conf;
}
NGINX_CONF

    log_success "Generated nginx.conf: $output_file"
}

################################################################################
# GENERATE DEFAULT NGINX SITE CONFIG
################################################################################

generate_default_site_config() {
    local output_file="${1:-.fb/nginx/sites-enabled/default.conf}"
    local www_dir="${2:-/var/www/html}"

    log_info "Generating default Nginx site configuration..."

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << DEFAULT_CONF
server {
    listen 80 default_server;
    listen [::]:80 default_server;

    server_name _;
    root ${www_dir};
    index index.php index.html index.htm;

    # Logs
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    # Character encoding
    charset utf-8;

    # Disable direct access to sensitive files
    location ~ ^/wp-config\\.php {
        deny all;
    }

    location ~ /\\.htaccess {
        deny all;
    }

    location ~ /\\. {
        deny all;
    }

    # PHP processing
    location ~ \\.php\$ {
        fastcgi_pass php:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param SCRIPT_NAME \$fastcgi_script_name;
        include fastcgi_params;
    }

    # WordPress rewrites
    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }

    # Cache static assets
    location ~* \\.(jpg|jpeg|png|gif|ico|css|js|svg|webp)$ {
        expires 365d;
        add_header Cache-Control "public, immutable";
    }
}
DEFAULT_CONF

    log_success "Generated default site config: $output_file"
}

################################################################################
# GENERATE MYSQL CONFIG
################################################################################

generate_mysql_conf() {
    local output_file="${1:-.fb/mysql/my.cnf}"

    log_info "Generating MySQL configuration..."

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << MYSQL_CONF
[mysqld]
skip-host-cache
skip-name-resolve

# MySQL Server Settings
max_connections = 100
wait_timeout = 600
max_allowed_packet = 256M
thread_stack = 192K
thread_cache_size = 8
myisam_recover_options = BACKUP
key_buffer_size = 16M
table_open_cache = 4000

# InnoDB Settings
default-storage-engine = InnoDB
innodb_buffer_pool_size = 256M
innodb_log_file_size = 100M
innodb_file_per_table = 1
innodb_flush_log_at_trx_commit = 0

# Character Set
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

# Slow Query Log
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 2

[client]
default-character-set = utf8mb4

[mysql]
init_command = "SET NAMES utf8mb4"

[mysqld_safe]
socket = /var/run/mysqld/mysqld.sock
nice = 0
MYSQL_CONF

    log_success "Generated MySQL config: $output_file"
}

################################################################################
# GENERATE PHP-FPM WWW.CONF
################################################################################

generate_php_fpm_conf() {
    local output_file="${1:-.fb/php/www.conf}"

    log_info "Generating PHP-FPM www.conf..."

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << PHP_FPM_CONF
[www]
user = wordpress
group = wordpress
listen = 0.0.0.0:9000
listen.allowed_clients = any

pm = dynamic
pm.max_children = 20
pm.start_servers = 10
pm.min_spare_servers = 5
pm.max_spare_servers = 15

env[PATH] = /usr/local/bin:/usr/bin:/bin
env[TMP] = /tmp
env[TMPDIR] = /tmp
env[TEMP] = /tmp

php_flag[display_errors] = on
php_admin_flag[log_errors] = on
php_admin_value[memory_limit] = 512M
php_admin_value[post_max_size] = 200M
php_admin_value[upload_max_filesize] = 200M
PHP_FPM_CONF

    log_success "Generated PHP-FPM www.conf: $output_file"
}

################################################################################
# GENERATE ALL FILES (COMPLETE SETUP)
################################################################################

generate_all_files() {
    local project_root="$1"
    local mysql_version="${2:-5.7}"
    local node_version="${3:-20}"
    local memory_limit="${4:-512M}"
    local upload_max_size="${5:-200M}"
    # Optional path parameters (can be overridden from fb.sh or other callers)
    local rel_config_dir="${6:-./.fb}"
    local rel_www_dir="${7:-./www}"
    local rel_context_path="${8:-.}"

    log_section "Generating All Configuration Files"

    local config_dir="${project_root}/.fb"
    local dockerfiles_dir="${config_dir}/dockerfiles"
    local nginx_dir="${config_dir}/nginx"
    local php_dir="${config_dir}/php"
    local mysql_dir="${config_dir}/mysql"

    # Create directory structure
    mkdir -p "$dockerfiles_dir" "$nginx_dir/sites-enabled" "$php_dir" "${project_root}/www"

    # MySQL dir must exist but may be already created as directory
    if [[ ! -d "$mysql_dir" ]]; then
        mkdir -p "$mysql_dir"
    fi

    # Generate all files
    generate_docker_compose "$project_root" "$rel_config_dir" "$rel_www_dir" "$rel_context_path" "$mysql_version" "$node_version" "${config_dir}/docker-compose.yml"
    generate_php_dockerfile "8.1" "${dockerfiles_dir}/php.dockerfile"
    generate_php_dockerfile "7.4" "${dockerfiles_dir}/php7.dockerfile"
    generate_nginx_dockerfile "${dockerfiles_dir}/nginx.dockerfile"
    generate_php_ini "$memory_limit" "$upload_max_size" "${php_dir}/php.ini"
    generate_php_fpm_conf "${php_dir}/www.conf"
    generate_nginx_conf "${nginx_dir}/nginx.conf"
    generate_default_site_config "${nginx_dir}/sites-enabled/default.conf" "$rel_www_dir"

    # Only generate mysql.cnf if it doesn't exist (preserve existing)
    local mysql_conf_file="${mysql_dir}/my.cnf"
    if [[ ! -f "$mysql_conf_file" ]]; then
        generate_mysql_conf "$mysql_conf_file"
    else
        log_info "MySQL config already exists: $mysql_conf_file (skipped)"
    fi

    log_success "All configuration files generated successfully!"
}

################################################################################
# GENERATE .env
################################################################################


create_default_env() {
    local ENV_FILE="$1"

    # Ensure the directory exists
    mkdir -p "$(dirname "$ENV_FILE")"

    # Now create the file
    cat > "$ENV_FILE" << 'EOF'
# fb Environment Configuration
COMPOSE_PROJECT_NAME=fb
MYSQL_ROOT_PASSWORD=Admin123
DB_ROOT_PASSWORD=Admin123
WP_DEBUG=1
NGINX_PORT=80
NGINX_HTTPS_PORT=443
MYSQL_PORT=3306
PHPMYADMIN_PORT=8080
MAILHOG_SMTP_PORT=1025
MAILHOG_UI_PORT=8025
NODE_PORT=5173
PHP_MEMORY_LIMIT=512M
PHP_UPLOAD_MAX_SIZE=200M
TZ=UTC
DOCKER_BUILDKIT=1
COMPOSE_DOCKER_CLI_BUILD=1
EOF

    log_success "Created default .env"
}


create_initial_config() {
    local SITES_CONFIG="$1"
    local project_name="$2"
    local mysql_version="$3"
    local node_version="$4"

    cat > "$SITES_CONFIG" << EOF
{
  "version": "1.0.0",
  "projectName": "$project_name",
  "global": {
    "dockerComposeVersion": "3.8",
    "mysqlVersion": "$mysql_version",
    "nginxVersion": "stable-alpine",
    "phpVersions": [
     "8.1",
     "7.4"
    ],
    "nodeVersion": "$node_version",
    "admin": {
      "username": "developer",
      "password": "Farmerdev#17"
    },
    "wordpress": {
      "permalinkStructure": "/%postname%/"
    },
    "plugins": [
      {
        "slug": "advanced-custom-fields-pro",
        "active": true,
        "url": "https://connect.advancedcustomfields.com/v2/plugins/download?s=web&p=pro&k=MTc1ZGQzMDFkMjA3YjY5ZWIzMjAzYjU0NDA2NjIxZTc1MzRlMTQwNzczZjY4NjQzN2IwOWFj"
      },
      {
        "slug": "block-editor-bootstrap-blocks",
        "active": false
      }
    ]
  },
  "theme": {
    "repo": "git@github.com:Farmerbit/flynt-gutenberg-starter.git",
    "name": "farmerbit"
  },
  "sites": {}
}
EOF
    log_success "Created sites.config.json"
}