#!/bin/bash

################################################################################
# WordPress Utilities Library
################################################################################



################################################################################
# WP-CLI Execution Wrapper
################################################################################

# Execute WP command - tries local WP-CLI first, then Docker
# Usage: wp_exec [--service=SERVICE] [--compose=FILE] [WP_ARGS...]
wp_exec() {
    local service="${WP_CONTAINER:-php}"
    local compose_file="${DOCKER_COMPOSE_FILE:-${CONFIG_DIR:-.}/docker-compose.yml}"

    # Parse optional parameters
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --service=*)
                service="${1#--service=}"
                shift
                ;;
            --compose=*)
                compose_file="${1#--compose=}"
                shift
                ;;
            *)
                break
                ;;
        esac
    done

    # If wp is available locally, use it
    if command -v wp &> /dev/null; then
        wp "$@"
        return $?
    fi

    # Otherwise use Docker via docker_exec
    docker_exec "$compose_file" "$service" wp "$@"
    return $?
}

################################################################################
# WordPress Installation Functions
################################################################################

# Download WordPress core
download_wordpress() {
    local target_dir="$1"

    local wp_version="${2:-latest}"
    local docker_compose_file="${3:-}"
    local php_version="${4:-8.1}"

    # Determine PHP service based on version
    local php_service=$(get_php_service "$php_version")

    # Create target directory if it doesn't exist
    mkdir -p "$target_dir" || {
        log_error "Failed to create directory: $target_dir"
        return 1
    }

    log_info "Downloading WordPress $wp_version to $target_dir..."

    # Use Docker if docker-compose file is provided and available
    if [[ -n "$docker_compose_file" ]] && [[ -f "$docker_compose_file" ]] && command -v docker compose &> /dev/null; then
        docker compose -f "$docker_compose_file" exec -T "$php_service" wp core download --path="$target_dir" --version="$wp_version" --allow-root 2>/dev/null || {
            # Fallback: download manually using wget/curl
            log_info "Falling back to manual download..."
            download_wordpress_manual "$target_dir" "$wp_version" "en_US"
            return $?
        }
    else
        # Fallback to local wp-cli or manual download
        if command -v wp &> /dev/null; then
            wp core download --path="$target_dir" --version="$wp_version" --allow-root || {
                log_info "Falling back to manual download..."
                download_wordpress_manual "$target_dir" "$wp_version" "en_US"
                return $?
            }
        else
            download_wordpress_manual "$target_dir" "$wp_version" "en_US"
        fi
    fi

    log_success "WordPress downloaded successfully"
}

# Manual WordPress download
download_wordpress_manual() {
    local target_dir="$1"
    local wp_version="${2:-latest}"
    local locale="${3:-en_US}" # Default to English if not specified

    local archive_url

    if [[ "$locale" == "en_US" ]]; then
        if [[ "$wp_version" == "latest" ]]; then
            archive_url="https://wordpress.org/latest.tar.gz"
        else
            archive_url="https://wordpress.org/wordpress-${wp_version}.tar.gz"
        fi
    else
        if [[ "$wp_version" == "latest" ]]; then
            archive_url="https://${locale%%_*}.wordpress.org/latest-${locale}.tar.gz"
        else
            archive_url="https://${locale%%_*}.wordpress.org/wordpress-${wp_version}-${locale}.tar.gz"
        fi
    fi

    local temp_dir
    temp_dir=$(mktemp -d)

    log_info "Downloading from: $archive_url"

    if command -v wget &> /dev/null; then
        wget -q -O "$temp_dir/wordpress.tar.gz" "$archive_url" || {
            log_error "Failed to download WordPress"
            rm -rf "$temp_dir"
            return 1
        }
    elif command -v curl &> /dev/null; then
        curl -sL -o "$temp_dir/wordpress.tar.gz" "$archive_url" || {
            log_error "Failed to download WordPress"
            rm -rf "$temp_dir"
            return 1
        }
    else
        log_error "wget or curl required to download WordPress"
        rm -rf "$temp_dir"
        return 1
    fi

    # Extract
    tar -xzf "$temp_dir/wordpress.tar.gz" -C "$target_dir" --strip-components=1
    rm -rf "$temp_dir"

    log_success "WordPress (${locale}) extracted to $target_dir"
}

# Create WordPress configuration
create_wp_config() {
    local site_dir="$1"
    local db_name="$2"
    local db_user="${3:-root}"
    local db_password="${4:-}"
    local db_host="${5:-mysql}"

    local wp_config="$site_dir/wp-config.php"

    if [[ -f "$wp_config" ]]; then
        log_warn "wp-config.php already exists"
        return 0
    fi

    # Verify directory exists and is writable
    if [[ ! -d "$site_dir" ]]; then
        log_error "Site directory does not exist: $site_dir"
        return 1
    fi

    if [[ ! -w "$site_dir" ]]; then
        log_error "Site directory is not writable: $site_dir"
        return 1
    fi

    log_info "Creating wp-config.php..."

    # Generate salts from WordPress.org API
    local salts=$(curl -s https://api.wordpress.org/secret-key/1.1/salt/ 2>/dev/null)

    # Fallback salts if API is unavailable
    if [[ -z "$salts" ]]; then
        log_warn "Could not fetch salts from WordPress.org API, using defaults"
        salts=$(cat << 'SALTS'
define('AUTH_KEY',         'put your unique phrase here');
define('SECURE_AUTH_KEY',  'put your unique phrase here');
define('LOGGED_IN_KEY',    'put your unique phrase here');
define('NONCE_KEY',        'put your unique phrase here');
define('AUTH_SALT',        'put your unique phrase here');
define('SECURE_AUTH_SALT', 'put your unique phrase here');
define('LOGGED_IN_SALT',   'put your unique phrase here');
define('NONCE_SALT',       'put your unique phrase here');
SALTS
        )
    fi

    # Create wp-config.php
    cat > "$wp_config" << WPCONFIG
<?php
/**
 * The base configuration for WordPress
 * Generated by fb
 */

// Database configuration
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASSWORD', '$db_password');
define('DB_HOST', '$db_host');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

// Table prefix
\$table_prefix = 'wp_';

// Authentication Unique Keys and Salts
$salts

// WordPress Debugging
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
define('WP_DEBUG_LOG_FILE', dirname(__FILE__) . '/wp-content/debug.log');

// Absolute path to WordPress
if (! defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}

// Load WordPress
require_once ABSPATH . 'wp-settings.php';
WPCONFIG

    # Verify file was created
    if [[ ! -f "$wp_config" ]]; then
        log_error "Failed to create wp-config.php at $wp_config"
        return 1
    fi

    if [[ ! -s "$wp_config" ]]; then
        log_error "wp-config.php is empty"
        return 1
    fi

    log_success "wp-config.php created successfully"
    log_info "  Location: $wp_config"
    log_info "  Database: $db_name@$db_host"
    return 0
}

# Install WordPress
install_wordpress() {
    local site_name="$1"
    local site_url="$2"
    local admin_user="${3:-developer}"
    local admin_password="${4:-Farmerdev#17}"
    local admin_email="${5:-admin@example.com}"
    local site_dir="${6:-.}"
    local docker_compose_file="${7:-}"
    local php_version="${8:-8.1}"
    local php_service=$(get_php_service "$php_version")
    
    log_info "Installing WordPress for site: $site_name..."

    # Verify wp-config.php exists
    if [[ ! -f "$site_dir/wp-config.php" ]]; then
        log_error "WordPress installation failed: wp-config.php not found at $site_dir/wp-config.php"
        return 1
    fi

    log_info "  Database name: $(grep "DB_NAME" "$site_dir/wp-config.php" | head -1 | sed "s/.*DB_NAME', '//" | sed "s/').*//")"
    log_info "  Database host: $(grep "DB_HOST" "$site_dir/wp-config.php" | head -1 | sed "s/.*DB_HOST', '//" | sed "s/').*//")"
    log_info "  WordPress URL: $site_url"

    # Container path is now the same as host path (no conversion needed)
    local container_path="$site_dir"
    if [[ -n "$docker_compose_file" ]] && [[ -f "$docker_compose_file" ]]; then
        log_debug "  Container path (same as host): $container_path"
    fi

    # Run WordPress installation
    # Note: --path must come BEFORE the subcommand (core) in wp-cli
    if wp_exec --service="$php_service" --compose="$docker_compose_file" --path="$container_path" core install \
        --locale="it" \
        --url="$site_url" \
        --title="$site_name" \
        --admin_user="$admin_user" \
        --admin_password="$admin_password" \
        --admin_email="$admin_email" \
        --allow-root 2>&1 | tee /tmp/wp_install_$site_name.log
    then
        log_success "WordPress installed successfully"
        return 0
    else
        local error_msg=$(tail -10 /tmp/wp_install_$site_name.log 2>/dev/null | grep -i "error\|fatal" | head -1)
        log_error "WordPress installation failed"
        if [[ -n "$error_msg" ]]; then
            log_error "  Reason: $error_msg"
        fi
        log_info "  Check database credentials in: $site_dir/wp-config.php"
        log_info "  Log file: /tmp/wp_install_$site_name.log"
        return 1
    fi
}

################################################################################
# WordPress Plugin Functions
################################################################################

# Install WordPress plugin
# Supports both slug (from WP.org) and direct download URLs
install_plugin() {
    local plugin_slug="$1"
    local site_path="${2:-.}"
    local activate="${3:-true}"
    local download_url="${4:-}"

    log_info "Installing plugin: $plugin_slug..."

    local activate_flag=""
    if [[ "$activate" == "true" ]]; then
        activate_flag="--activate"
    fi

    # Handle placeholder URLs for ACF Pro
    if [[ "$download_url" =~ LICENSE_KEY ]]; then
        log_warn "ACF Pro license key placeholder found. Set valid license in config: .global.plugins[].url"
        download_url=""
    fi

    # First, try WP-CLI if it's a slug (not a URL)
    if [[ ! "$plugin_slug" =~ ^https?:// ]]; then
        if wp_exec --path="$site_path" plugin install "$plugin_slug" $activate_flag --allow-root 2>/dev/null; then
            log_success "Plugin installed: $plugin_slug"
            return 0
        fi

        # If WP-CLI fails, try downloading from WordPress.org or custom URL
        # If no custom URL provided, auto-generate WordPress.org URL
        if [[ -z "$download_url" ]]; then
            download_url="https://downloads.wordpress.org/plugin/${plugin_slug}.zip"
            log_info "WP-CLI failed, trying download from WordPress.org..."
        fi
    fi

    # Install from URL (direct download)
    if [[ -n "$download_url" ]] || [[ "$plugin_slug" =~ ^https?:// ]]; then
        local url="${download_url:-$plugin_slug}"
        log_info "Downloading plugin from URL: $url"

        install_plugin_from_url "$url" "$site_path" "$activate" "$plugin_slug"
        return $?
    fi

    log_error "Failed to install plugin: $plugin_slug"
    return 1
}

# Install plugin from direct URL download
install_plugin_from_url() {
    local download_url="$1"
    local site_path="${2:-.}"
    local activate="${3:-true}"
    local plugin_name="${4:-plugin}"

    local plugins_dir="$site_path/wp-content/plugins"
    mkdir -p "$plugins_dir"

    # Download plugin ZIP
    local temp_file=$(mktemp --suffix=.zip)
    log_info "Downloading plugin archive..."

    if command -v wget &> /dev/null; then
        wget -q -O "$temp_file" "$download_url" 2>/dev/null
    elif command -v curl &> /dev/null; then
        curl -sL -o "$temp_file" "$download_url" 2>/dev/null
    else
        log_error "Neither wget nor curl available for download"
        rm -f "$temp_file"
        return 1
    fi

    if [[ ! -f "$temp_file" ]] || [[ ! -s "$temp_file" ]]; then
        log_error "Failed to download plugin from: $download_url"
        rm -f "$temp_file"
        return 1
    fi

    # Extract plugin
    log_info "Extracting plugin archive..."
    unzip -q "$temp_file" -d "$plugins_dir" 2>/dev/null

    if [[ $? -ne 0 ]]; then
        log_error "Failed to extract plugin archive"
        rm -f "$temp_file"
        return 1
    fi

    log_success "Plugin downloaded and extracted: $plugin_name"

    # Activate plugin if requested
    if [[ "$activate" == "true" ]]; then
        # Find plugin folder (most recently extracted folder)
        local plugin_folder=$(ls -d "$plugins_dir"/*/ 2>/dev/null | tail -1 | xargs basename)

        if [[ -n "$plugin_folder" ]]; then
            if wp_exec --path="$site_path" plugin activate "$plugin_folder" --allow-root 2>/dev/null; then
                log_success "Plugin activated: $plugin_name"
            else
                log_warn "Plugin installed but activation may be manual: $plugin_name"
            fi
        fi
    fi

    rm -f "$temp_file"
    return 0
}

# Activate plugin
activate_plugin() {
    local plugin_slug="$1"
    local site_path="${2:-.}"

    log_info "Activating plugin: $plugin_slug..."

    wp_exec --path="$site_path" plugin activate "$plugin_slug" --allow-root || {
        log_error "Failed to activate plugin: $plugin_slug"
        return 1
    }

    log_success "Plugin activated: $plugin_slug"
}

# Activate plugins from config
activate_site_plugins_from_config() {
    local config_file="$1"
    local site_path="${2:-.}"

    if [[ ! -f "$config_file" ]]; then
        log_warn "Config file not found: $config_file"
        return 1
    fi

    log_info "Activating configured plugins..."

    # Convert host path to container path if needed
    # Container path is now the same as host path (no conversion needed)
    local container_path="$site_path"

    local plugin_count=$(jq '.global.plugins | length' "$config_file" 2>/dev/null || echo 0)

    if [[ $plugin_count -gt 0 ]]; then
        for ((i=0; i<plugin_count; i++)); do
            local plugin_slug=$(jq -r ".global.plugins[$i].slug" "$config_file" 2>/dev/null)
            local plugin_active=$(jq -r ".global.plugins[$i].active // true" "$config_file" 2>/dev/null)

            if [[ -n "$plugin_slug" ]] && [[ "$plugin_active" == "true" ]]; then
                # Try to activate via wp-cli
                if wp_exec --path="$container_path" plugin activate "$plugin_slug" --allow-root 2>/dev/null; then
                    log_success "Plugin activated: $plugin_slug"
                else
                    log_warn "Could not activate plugin: $plugin_slug (may be already active)"
                fi
            fi
        done
    fi

    return 0
}

# Deactivate plugin
deactivate_plugin() {
    local plugin_slug="$1"
    local site_path="${2:-.}"

    log_info "Deactivating plugin: $plugin_slug..."

    wp_exec --path="$site_path" plugin deactivate "$plugin_slug" --allow-root || {
        log_error "Failed to deactivate plugin: $plugin_slug"
        return 1
    }

    log_success "Plugin deactivated: $plugin_slug"
}

# List installed plugins
list_plugins() {
    local site_path="${1:-.}"

    wp_exec plugin list --path="$site_path" --allow-root
}

################################################################################
# WordPress Theme Functions
################################################################################

# Install theme
install_theme() {
    local theme_slug="$1"
    local site_path="${2:-.}"
    local activate="${3:-false}"

    log_info "Installing theme: $theme_slug..."

    local activate_flag=""
    if [[ "$activate" == "true" ]]; then
        activate_flag="--activate"
    fi

    wp_exec theme install "$theme_slug" $activate_flag --path="$site_path" --allow-root || {
        log_error "Failed to install theme: $theme_slug"
        return 1
    }

    log_success "Theme installed: $theme_slug"
}

# Activate theme
activate_theme() {
    local theme_slug="$1"
    local site_path="${2:-.}"

    log_info "Activating theme: $theme_slug..."

    # Container path is now the same as host path (no conversion needed)
    local container_path="$site_path"

    wp_exec --path="$container_path" theme activate "$theme_slug" --allow-root || {
        log_error "Failed to activate theme: $theme_slug"
        return 1
    }

    log_success "Theme activated: $theme_slug"
}

################################################################################
# Theme Configuration Functions (from sites.config.json)
################################################################################

# Get global theme repository from config
get_theme_repo() {
    local config_file="$1"
    get_config_value "$config_file" ".theme.repo" ""
}

# Get global theme name from config
get_theme_name() {
    local config_file="$1"
    get_config_value "$config_file" ".theme.name" ""
}

# Get site theme name from config
get_site_theme() {
    local config_file="$1"
    local site_name="$2"

    # Extract theme name from config
    # If theme is an object with .name property, extract it
    # If theme is a string, use it directly
    # Otherwise use default
    jq -r ".sites.\"$site_name\".theme.name // .sites.\"$site_name\".theme // \"twentytwentythree\"" "$config_file" 2>/dev/null || echo "twentytwentythree"
}

# Install theme from Git repository
install_theme_from_git() {
    local repo_url="$1"
    local theme_name="$2"
    local wp_themes_dir="$3"
    local docker_compose_file="${4:-}"
    local php_version="${5:-8.1}"

    # Determine PHP service based on version
    local php_service=$(get_php_service "$php_version")

    if [[ -z "$repo_url" ]] || [[ -z "$theme_name" ]] || [[ -z "$wp_themes_dir" ]]; then
        log_error "Missing required parameters for git theme installation"
        return 1
    fi

    local theme_dir="$wp_themes_dir/$theme_name"

    # Check if theme already exists
    if [[ -d "$theme_dir" ]]; then
        log_warn "Theme directory already exists: $theme_dir"
        return 0
    fi

    log_info "Cloning theme from: $repo_url"
    log_info "Destination: $theme_dir"

    # Create themes directory if it doesn't exist
    mkdir -p "$wp_themes_dir"

    # Clone the repository
    if git clone "$repo_url" "$theme_dir" > /dev/null 2>&1; then
        log_success "Theme cloned successfully: $theme_name"

        # Install theme dependencies with Composer if composer.json exists
        if [[ -f "$theme_dir/composer.json" ]]; then
            log_info "Installing theme dependencies with Composer..."

            if [[ -n "$docker_compose_file" ]] && [[ -f "$docker_compose_file" ]] && command -v docker compose &> /dev/null; then
                # Container path is now the same as host path (no conversion needed)
                local container_theme_dir="$theme_dir"

                # Execute composer install from PHP container
                docker compose -f "$docker_compose_file" exec -T "$php_service" \
                    sh -c "cd '$container_theme_dir' && composer install --no-interaction --prefer-dist" > /dev/null 2>&1

                if [[ $? -eq 0 ]]; then
                    log_success "Theme dependencies installed via Composer"
                else
                    log_warn "Failed to install theme dependencies via Docker. Try running: docker compose exec php sh -c 'cd $container_theme_dir && composer install'"
                fi
            else
                # Try to run composer locally as fallback
                if command -v composer &> /dev/null; then
                    composer install --working-dir="$theme_dir" --no-interaction --prefer-dist > /dev/null 2>&1
                    if [[ $? -eq 0 ]]; then
                        log_success "Theme dependencies installed locally"
                    else
                        log_warn "Failed to install theme dependencies with local Composer"
                    fi
                else
                    log_warn "Composer not available locally or in Docker. Theme dependencies not installed."
                    log_info "To install manually: composer install in $theme_dir"
                fi
            fi
        fi

        return 0
    else
        log_error "Failed to clone theme from: $repo_url"
        return 1
    fi
}

# Install theme from config (Git or WP.org)
install_theme_from_config() {
    local config_file="$1"
    local site_name="$2"
    local site_path="$3"
    local docker_compose_file="${4:-}"
    local php_version="${5:-8.1}"

    # Determine PHP service based on version
    local php_service=$(get_php_service "$php_version")

    if [[ -z "$config_file" ]] || [[ -z "$site_name" ]] || [[ -z "$site_path" ]]; then
        log_error "Missing required parameters for config-based theme installation"
        return 1
    fi

    # Get site theme name
    local site_theme=$(get_site_theme "$config_file" "$site_name")
    if [[ -z "$site_theme" ]]; then
        log_warn "No theme configured for site: $site_name, using default: twentytwentythree"
        site_theme="twentytwentythree"
    fi

    # Get global theme repo
    local theme_repo=$(get_theme_repo "$config_file")
    local global_theme_name=$(get_theme_name "$config_file")

    # If site uses the global/custom theme, clone from repo
    if [[ "$site_theme" == "$global_theme_name" ]] && [[ -n "$theme_repo" ]]; then
        log_info "Installing custom theme from Git: $site_theme"
        install_theme_from_git "$theme_repo" "$site_theme" "$site_path/wp-content/themes" "$docker_compose_file" "$php_service" || {
            log_error "Failed to install custom theme"
            return 1
        }
    else
        # Otherwise use WP-CLI to install from WordPress.org
        log_info "Installing theme from WordPress.org: $site_theme"
        install_theme "$site_theme" "$site_path" "false" || {
            log_error "Failed to install theme from WordPress.org"
            return 1
        }
    fi

    return 0
}

# Activate theme from config
activate_theme_from_config() {
    local config_file="$1"
    local site_name="$2"
    local site_path="$3"

    if [[ -z "$config_file" ]] || [[ -z "$site_name" ]] || [[ -z "$site_path" ]]; then
        log_error "Missing required parameters for theme activation"
        return 1
    fi

    # Get site theme name
    local site_theme=$(get_site_theme "$config_file" "$site_name")
    if [[ -z "$site_theme" ]]; then
        site_theme="twentytwentythree"
    fi

    log_info "Activating theme: $site_theme"
    activate_theme "$site_theme" "$site_path" || {
        log_error "Failed to activate theme: $site_theme"
        return 1
    }

    return 0
}

################################################################################
# WordPress Configuration Functions
################################################################################

# Set WordPress permalink structure
set_permalink_structure() {
    local site_path="${1:-.}"
    local permalink_structure="${2:-/%postname%/}"
    local docker_compose_file="${3:-}"
    local php_version="${4:-8.1}"

    log_info "Configuring permalink structure..."

    # Container path is now the same as host path (no conversion needed)
    local container_path="$site_path"

    if [[ -n "$docker_compose_file" ]] && [[ -f "$docker_compose_file" ]]; then
        # Use docker
        if wp_exec --path="$container_path" option update permalink_structure "$permalink_structure" --allow-root 2>/dev/null; then
            # Flush rewrite rules
            wp_exec --path="$container_path" rewrite flush --hard --allow-root 2>/dev/null
            log_success "Permalink structure configured: $permalink_structure"
            return 0
        fi
    fi

    log_warn "Could not set permalink structure (WordPress may not be fully installed yet)"
    return 1
}

################################################################################
# WordPress User Functions
################################################################################

# Create WordPress user
create_wp_user() {
    local username="$1"
    local email="$2"
    local password="$3"
    local role="${4:-administrator}"
    local site_path="${5:-.}"

    log_info "Creating WordPress user: $username..."

    wp_exec user create "$username" "$email" \
        --user_pass="$password" \
        --role="$role" \
        --path="$site_path" \
        --allow-root || {
        log_error "Failed to create user: $username"
        return 1
    }

    log_success "User created: $username"
}

# Set WordPress option
set_wp_option() {
    local option_name="$1"
    local option_value="$2"
    local site_path="${3:-.}"

    wp_exec option update "$option_name" "$option_value" --path="$site_path" --allow-root
}

################################################################################
# WordPress Database Functions
################################################################################

# Get WordPress database name for site
get_wp_db_name() {
    local site_name="$1"
    echo "${site_name}_db"
}

# Check WordPress tables exist
check_wp_tables() {
    local site_path="$1"

    wp_exec db tables --path="$site_path" --allow-root > /dev/null 2>&1
    return $?
}
