#!/bin/bash

################################################################################
# Site Installer Library
################################################################################


################################################################################
# CREATE SITE DIRECTORY
################################################################################

create_site_directory() {
    local site_name="$1"
    local domain="$2"
    local www_dir="$3"

    local site_dir="$www_dir/$site_name"

    # Create the directory structure
    if mkdir -p "$site_dir" 2>/dev/null; then
        # Create subdirectories for WordPress
        mkdir -p "$site_dir/wp-content/themes" 2>/dev/null
        mkdir -p "$site_dir/wp-content/plugins" 2>/dev/null
        mkdir -p "$site_dir/wp-content/uploads" 2>/dev/null

        # Set proper permissions
        chmod 755 "$site_dir" 2>/dev/null
        chmod 755 "$site_dir/wp-content" 2>/dev/null

        # Output only the path (no colors)
        echo "$site_dir"
        return 0
    else
        return 1
    fi
}

################################################################################
# DISPLAY SITE SUMMARY
################################################################################

display_site_summary() {
    local site_name="$1"
    local domain="$2"
    local php_version="$3"
    local db_name="$4"
    local admin_user="$5"
    local admin_pass="$6"
    local admin_email="$7"
    local theme="$8"

    printf "\n${GREEN}✓ Site '$site_name' created successfully!${NC}\n\n"

    printf "${BOLD}Site Details:${NC}\n"
    printf "  Name:        $site_name\n"
    printf "  Domain:      $domain\n"
    printf "  PHP Version: $php_version\n"
    printf "  Database:    $db_name\n"
    printf "  Admin User:  $admin_user\n"
    printf "  Admin Email: $admin_email\n"
    printf "  Theme:       $theme\n"

    printf "\n${BOLD}Next Steps:${NC}\n"
    printf "  1. Run: ${CYAN}fb start${NC}\n"
    printf "  2. Visit: ${CYAN}https://$domain${NC}\n"
    printf "  3. Login with: ${CYAN}$admin_user${NC} / ${CYAN}$admin_pass${NC}\n\n"
}

################################################################################
# ADD SITE TO CONFIG (Simplified version for use in site-installer)
################################################################################

add_site_directory_structure() {
    local site_name="$1"
    local site_dir="$2"

    # Additional setup if needed
    log_debug "Site directory structure created for: $site_name at $site_dir"

    return 0
}


################################################################################
# GENERATE NGINX CONFIG
################################################################################


generate_nginx_config() {
    local site_name="$1"
    local domain="$2"
    local project_root="${3:-.}"
    local config_dir="${4:-.}"
    local php_version="${5:-8.1}"
    local www_dir="${6:-.}"

    local nginx_dir="$config_dir/nginx/sites-enabled"
    local config_file="$nginx_dir/${site_name}.conf"
    local site_root="${www_dir}/${site_name}"

    # Determine PHP container name based on version
    local php_container="php"
    if [[ "$php_version" == "7.4" ]]; then
        php_container="php7"
    fi

    log_info "Generating Nginx configuration for $site_name (PHP $php_version -> $php_container:9000)..."
    log_debug "Site root path: $site_root"

    mkdir -p "$nginx_dir"

    cat > "$config_file" << NGINX_CONFIG
# Nginx configuration for $site_name

server {
  listen 80;
  listen [::]:80;
  server_name $domain;
  return 301 https://\$host\$request_uri;  # Redirect HTTP to HTTPS
}

server {
  listen 443 ssl;
  listen [::]:443 ssl;
  http2 on;
  server_name $domain;

  index index.php index.html index.htm;
  access_log /var/log/nginx/${site_name}_access.log;
  error_log /var/log/nginx/${site_name}_error.log;
  root ${site_root};

  ssl_certificate /etc/nginx/certs/cert.pem;
  ssl_certificate_key /etc/nginx/certs/key.pem;
  ssl_protocols TLSv1.2 TLSv1.3;
  ssl_ciphers HIGH:!aNULL:!MD5;
  ssl_prefer_server_ciphers on;
  ssl_session_cache shared:SSL:10m;
  ssl_session_timeout 10m;


  # Security headers
  add_header X-Frame-Options "SAMEORIGIN" always;
  add_header X-Content-Type-Options "nosniff" always;
  add_header X-XSS-Protection "1; mode=block" always;
  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

  # Character encoding
  charset utf-8;
  
  # Disable direct access to wp-config.php
  location ~ ^/wp-config\.php {
    deny all;
  }

  # Disable direct access to .htaccess
  location ~ /\.htaccess {
    deny all;
  }

  # Block access to hidden files and directories
  location ~ /\. {
    deny all;
  }

  location ~ \.php$ {
    try_files \$uri =404;
    fastcgi_split_path_info ^(.+\.php)(/.+)$;
    fastcgi_pass ${php_container}:9000;
    fastcgi_index index.php;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
    fastcgi_param PATH_INFO \$fastcgi_path_info;
  }

  location / {
    try_files \$uri \$uri/ /index.php?\$args;
  }
 
  # Optimize images
  location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg)$ {
    expires 365d;
    add_header Cache-Control "public, immutable";
  }
}
NGINX_CONFIG

    log_success "Nginx configuration generated: $config_file"
}
