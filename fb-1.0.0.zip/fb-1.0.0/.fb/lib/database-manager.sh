#!/bin/bash

################################################################################
# Database Manager Library
################################################################################


################################################################################
# CREATE DATABASE
################################################################################

create_database_mysql() {
    local db_name="$1"
    local db_user="${2:-root}"
    local db_pass="${3:-Admin123}"
    local db_host="${4:-mysql}"
    local docker_compose="${5:-docker-compose.yml}"
    local mysql_container="${6:-mysql}"

    log_info "Creating database: $db_name..."

    # Try via Docker container first (preferred)
    if [[ -f "$docker_compose" ]] && command -v docker compose &> /dev/null; then
        docker compose -f "$docker_compose" exec -T "$mysql_container" mysql \
            -u "$db_user" \
            -p"$db_pass" \
            -e "CREATE DATABASE IF NOT EXISTS \`$db_name\`;" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database created: $db_name"
            return 0
        fi
    fi

    # Fallback to direct mysql command
    if command -v mysql &> /dev/null; then
        mysql -u "$db_user" -p"$db_pass" -h "$db_host" \
            -e "CREATE DATABASE IF NOT EXISTS \`$db_name\`;" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database created: $db_name"
            return 0
        fi
    fi

    log_warn "Could not create database automatically"
    return 1
}

################################################################################
# CHECK IF DATABASE EXISTS
################################################################################

database_exists() {
    local db_name="$1"
    local db_user="${2:-root}"
    local db_pass="${3:-Admin123}"
    local docker_compose="${4:-docker-compose.yml}"
    local mysql_container="${5:-mysql}"

    if [[ -f "$docker_compose" ]] && command -v docker compose &> /dev/null; then
        docker compose -f "$docker_compose" exec -T "$mysql_container" mysql \
            -u "$db_user" \
            -p"$db_pass" \
            -e "USE \`$db_name\`;" 2>/dev/null
        return $?
    fi

    if command -v mysql &> /dev/null; then
        mysql -u "$db_user" -p"$db_pass" \
            -e "USE \`$db_name\`;" 2>/dev/null
        return $?
    fi

    return 1
}

################################################################################
# DROP DATABASE
################################################################################

drop_database() {
    local db_name="$1"
    local db_user="${2:-root}"
    local db_pass="${3:-Admin123}"
    local docker_compose="${4:-docker-compose.yml}"
    local mysql_container="${5:-mysql}"

    log_warn "Dropping database: $db_name..."

    if [[ -f "$docker_compose" ]] && command -v docker compose &> /dev/null; then
        docker compose -f "$docker_compose" exec -T "$mysql_container" mysql \
            -u "$db_user" \
            -p"$db_pass" \
            -e "DROP DATABASE IF EXISTS \`$db_name\`;" 2>/dev/null

        return $?
    fi

    if command -v mysql &> /dev/null; then
        mysql -u "$db_user" -p"$db_pass" \
            -e "DROP DATABASE IF EXISTS \`$db_name\`;" 2>/dev/null

        return $?
    fi

    return 1
}

################################################################################
# EXPORT DATABASE
################################################################################

export_database() {
    local db_name="$1"
    local output_file="$2"
    local db_user="${3:-root}"
    local db_pass="${4:-Admin123}"
    local docker_compose="${5:-docker-compose.yml}"
    local mysql_container="${6:-mysql}"

    log_info "Exporting database: $db_name..."

    if [[ -f "$docker_compose" ]] && command -v docker compose &> /dev/null; then
        docker compose -f "$docker_compose" exec -T "$mysql_container" mysqldump \
            -u "$db_user" \
            -p"$db_pass" \
            "$db_name" > "$output_file" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database exported to: $output_file"
            return 0
        fi
    fi

    if command -v mysqldump &> /dev/null; then
        mysqldump -u "$db_user" -p"$db_pass" "$db_name" > "$output_file" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database exported to: $output_file"
            return 0
        fi
    fi

    log_error "Failed to export database"
    return 1
}

################################################################################
# IMPORT DATABASE
################################################################################

import_database() {
    local db_name="$1"
    local input_file="$2"
    local db_user="${3:-root}"
    local db_pass="${4:-Admin123}"
    local docker_compose="${5:-docker-compose.yml}"
    local mysql_container="${6:-mysql}"

    if [[ ! -f "$input_file" ]]; then
        log_error "Input file not found: $input_file"
        return 1
    fi

    log_info "Importing database from: $input_file..."

    if [[ -f "$docker_compose" ]] && command -v docker compose &> /dev/null; then
        docker compose -f "$docker_compose" exec -T "$mysql_container" mysql \
            -u "$db_user" \
            -p"$db_pass" \
            "$db_name" < "$input_file" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database imported successfully"
            return 0
        fi
    fi

    if command -v mysql &> /dev/null; then
        mysql -u "$db_user" -p"$db_pass" "$db_name" < "$input_file" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database imported successfully"
            return 0
        fi
    fi

    log_error "Failed to import database"
    return 1
}

################################################################################
# REPLACE URL IN DATABASE (for domain migration)
################################################################################

replace_url_in_database() {
    local old_url="$1"
    local new_url="$2"
    local site_path="${3:-/var/www/html/sitename}"
    local docker_compose="${4:-docker-compose.yml}"
    local php_container="${5:-php}"

    if [[ -z "$old_url" ]] || [[ -z "$new_url" ]]; then
        log_error "old_url and new_url required"
        return 1
    fi

    log_info "Replacing URLs in database..."
    log_debug "  Old URL: $old_url"
    log_debug "  New URL: $new_url"

    if [[ -f "$docker_compose" ]] && command -v docker compose &> /dev/null; then
        # Use WP-CLI to replace URLs (handles serialized data correctly)
        if docker compose -f "$docker_compose" exec -T "$php_container" \
            wp search-replace "$old_url" "$new_url" --path="$site_path" --allow-root 2>&1 | tee /tmp/wp_replace_$$.log; then
            log_success "URLs replaced successfully"
            return 0
        else
            local error=$(tail -5 /tmp/wp_replace_$$.log 2>/dev/null | grep -i "error\|fatal" | head -1)
            if [[ -n "$error" ]]; then
                log_warn "URL replacement may have failed or WordPress not fully installed: $error"
            fi
            return 0  # Don't fail, WordPress might not be installed yet
        fi
    fi

    log_warn "Could not replace URLs (Docker not available)"
    return 1
}

################################################################################
# IMPORT MEDIA FROM FTP
################################################################################

import_media_from_ftp() {
    local ftp_host="$1"
    local ftp_user="$2"
    local ftp_pass="$3"
    local ftp_path="${4:-/public_html/wp-content/uploads}"
    local local_path="$5"
    local docker_compose="${6:-docker-compose.yml}"

    if [[ -z "$ftp_host" ]] || [[ -z "$ftp_user" ]] || [[ -z "$ftp_pass" ]] || [[ -z "$local_path" ]]; then
        log_error "Missing FTP credentials or local path"
        return 1
    fi

    log_info "Importing media from FTP..."
    log_debug "  FTP Host: $ftp_host"
    log_debug "  FTP Path: $ftp_path"
    log_debug "  Local Path: $local_path"

    # Create uploads directory if it doesn't exist
    mkdir -p "$local_path"

    # Check if lftp is available (preferred method)
    if command -v lftp &> /dev/null; then
        log_info "Using lftp to download media..."
        lftp -u "$ftp_user","$ftp_pass" "$ftp_host" << EOF
set ftp:ssl-allow no
set mirror:use-pget-n 5
mirror -R "$ftp_path" "$local_path" --verbose
quit
EOF
        if [[ $? -eq 0 ]]; then
            log_success "Media imported successfully via lftp"
            return 0
        else
            log_warn "lftp download failed, trying wget..."
        fi
    fi

    # Fallback to wget
    if command -v wget &> /dev/null; then
        log_info "Using wget to download media..."
        wget -r --ftp-user="$ftp_user" --ftp-password="$ftp_pass" \
            "ftp://$ftp_host$ftp_path/" -P "$local_path" --no-remove-listing 2>&1 | tail -5
        if [[ $? -eq 0 ]]; then
            log_success "Media imported successfully via wget"
            return 0
        fi
    fi

    # Fallback to curl
    if command -v curl &> /dev/null; then
        log_info "Using curl to download media..."
        curl -u "$ftp_user:$ftp_pass" -O "ftp://$ftp_host$ftp_path/*" -P "$local_path" 2>&1 | tail -5
        if [[ $? -eq 0 ]]; then
            log_success "Media imported successfully via curl"
            return 0
        fi
    fi

    log_error "No FTP download tool available (lftp, wget, or curl required)"
    return 1
}

################################################################################
# OPTIMIZE DATABASE
################################################################################

optimize_database() {
    local db_name="$1"
    local db_user="${2:-root}"
    local db_pass="${3:-Admin123}"
    local docker_compose="${4:-docker-compose.yml}"
    local mysql_container="${5:-mysql}"

    log_info "Optimizing database: $db_name..."

    if [[ -f "$docker_compose" ]] && command -v docker compose &> /dev/null; then
        docker compose -f "$docker_compose" exec -T "$mysql_container" mysqlcheck \
            -u "$db_user" \
            -p"$db_pass" \
            --optimize \
            "$db_name" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database optimized"
            return 0
        fi
    fi

    if command -v mysqlcheck &> /dev/null; then
        mysqlcheck -u "$db_user" -p"$db_pass" --optimize "$db_name" 2>/dev/null

        if [[ $? -eq 0 ]]; then
            log_success "Database optimized"
            return 0
        fi
    fi

    log_warn "Could not optimize database"
    return 1
}
