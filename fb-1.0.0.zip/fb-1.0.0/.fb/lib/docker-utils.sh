#!/bin/bash

################################################################################
# Docker Utilities Library
################################################################################


################################################################################
# Docker Check Functions
################################################################################

# Check if Docker is installed and running
check_docker() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        log_info "Install Docker from: https://docs.docker.com/get-docker/"
        return 1
    fi

    if ! docker ps > /dev/null 2>&1; then
        log_error "Docker daemon is not running"
        log_info "Start Docker with: sudo systemctl start docker"
        return 1
    fi

    log_debug "Docker is installed and running"
    return 0
}

# Check if Docker Compose is installed
check_docker_compose() {
    if ! command -v docker compose &> /dev/null; then
        log_error "Docker Compose is not installed"
        log_info "Install Docker Compose from: https://docs.docker.com/compose/install/"
        return 1
    fi

    log_debug "Docker Compose is installed"
    return 0
}

# Get running container count
get_running_container_count() {
    local compose_file="$1"

    if [[ ! -f "$compose_file" ]]; then
        echo "0"
        return
    fi

    docker compose -f "$compose_file" ps --services 2>/dev/null | wc -l
}

# Check if specific service is running
is_service_running() {
    local compose_file="$1"
    local service_name="$2"

    if [[ ! -f "$compose_file" ]]; then
        return 1
    fi

    docker compose -f "$compose_file" ps "$service_name" 2>/dev/null | grep -q "$service_name"
    return $?
}

# Get service container ID
get_service_container_id() {
    local compose_file="$1"
    local service_name="$2"

    if [[ ! -f "$compose_file" ]]; then
        return 1
    fi

    docker compose -f "$compose_file" ps -q "$service_name" 2>/dev/null
}

# Execute command in container
docker_exec() {
    local compose_file="$1"
    local service="$2"
    shift 2
    local cmd=("$@")

    if ! check_docker_compose; then
        return 1
    fi

    docker compose -f "$compose_file" exec -T "$service" "${cmd[@]}"
}

# Execute command in container (interactive)
docker_exec_interactive() {
    local compose_file="$1"
    local service="$2"
    shift 2
    local cmd=("$@")

    if ! check_docker_compose; then
        return 1
    fi

    docker compose -f "$compose_file" exec "$service" "${cmd[@]}"
}

# Get container logs
get_container_logs() {
    local compose_file="$1"
    local service="$2"
    local lines="${3:-50}"

    if ! check_docker_compose; then
        return 1
    fi

    docker compose -f "$compose_file" logs --tail="$lines" "$service"
}

# Health check for service
service_health_check() {
    local compose_file="$1"
    local service="$2"
    local max_attempts="${3:-30}"
    local delay="${4:-2}"

    local attempt=1

    log_info "Checking health of service: $service"

    while [[ $attempt -le $max_attempts ]]; do
        if is_service_running "$compose_file" "$service"; then
            log_success "Service $service is healthy"
            return 0
        fi

        log_debug "Waiting for $service... (attempt $attempt/$max_attempts)"
        sleep "$delay"
        ((attempt++))
    done

    log_error "Service $service failed to start"
    return 1
}


# Build Docker images
build_images() {
    local compose_file="$1"

    if ! check_docker_compose; then
        return 1
    fi

    log_section "Building Docker Images"

    docker compose -f "$compose_file" build || {
        log_error "Failed to build images"
        return 1
    }

    log_success "Images built successfully"
}

# Pull Docker images
pull_images() {
    local compose_file="$1"

    if ! check_docker_compose; then
        return 1
    fi

    log_section "Pulling Docker Images"

    docker compose -f "$compose_file" pull || {
        log_error "Failed to pull images"
        return 1
    }

    log_success "Images pulled successfully"
}

################################################################################
# Docker Network Utilities
################################################################################

# Get project network name
get_project_network() {
    local project_name="$1"
    echo "${project_name}_default"
}

# Check if network exists
network_exists() {
    local network_name="$1"
    docker network ls | grep -q "$network_name"
    return $?
}

# Create network if not exists
ensure_network() {
    local network_name="$1"

    if network_exists "$network_name"; then
        log_debug "Network already exists: $network_name"
        return 0
    fi

    log_info "Creating network: $network_name"
    docker network create "$network_name" || {
        log_error "Failed to create network"
        return 1
    }

    log_success "Network created: $network_name"
}
