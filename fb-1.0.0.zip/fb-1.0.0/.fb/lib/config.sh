#!/bin/bash

################################################################################
# Config Library - Configuration management utilities
################################################################################


################################################################################
# Configuration Functions
################################################################################

load_env() {
    local env_file="${1:-.env}"

    if [[ -f "$env_file" ]]; then
        set -a
        source "$env_file"
        set +a
        log_debug "Environment loaded from $env_file"
    fi
}

load_config() {
    local SITES_CONFIG="${1}"

    if [[ ! -f "$SITES_CONFIG" ]]; then
        log_error "Configuration file not found: $SITES_CONFIG"
        log_info "Initialize project with: fb init"
        return 1
    fi

    if ! command -v jq &> /dev/null; then
        log_error "jq is required but not installed"
        log_info "Install with: sudo apt-get install jq"
        return 1
    fi

    # Validate JSON
    if ! jq empty "$SITES_CONFIG" 2>/dev/null; then
        log_error "Invalid JSON in $SITES_CONFIG"
        return 1
    fi

    return 0
}

# Get config value from JSON using jq
get_config_value() {
    local config_file="$1"
    local key_path="$2"
    local default="${3:-}"

    if ! command -v jq &> /dev/null; then
        log_error "jq is required but not installed"
        return 1
    fi

    if [[ ! -f "$config_file" ]]; then
        log_warn "Config file not found: $config_file"
        return 1
    fi

    local value=$(jq -r "$key_path // \"$default\"" "$config_file" 2>/dev/null)

    if [[ $? -eq 0 ]] && [[ -n "$value" ]] && [[ "$value" != "null" ]]; then
        echo "$value"
        return 0
    fi

    if [[ -n "$default" ]]; then
        echo "$default"
        return 0
    fi

    return 1
}

# Set config value in JSON
set_config_value() {
    local config_file="$1"
    local key_path="$2"
    local value="$3"

    if ! command -v jq &> /dev/null; then
        log_error "jq is required but not installed"
        return 1
    fi

    if [[ ! -f "$config_file" ]]; then
        log_error "Config file not found: $config_file"
        return 1
    fi

    local temp_file=$(mktemp)
    jq --arg val "$value" "$key_path = \$val" "$config_file" > "$temp_file"

    if [[ $? -eq 0 ]]; then
        mv "$temp_file" "$config_file"
        return 0
    else
        rm -f "$temp_file"
        return 1
    fi
}

# List all sites from config
list_sites() {
    local config_file="$1"

    if ! command -v jq &> /dev/null; then
        log_error "jq is required but not installed"
        return 1
    fi

    if [[ ! -f "$config_file" ]]; then
        return 1
    fi

    # Handle both array and object formats
    jq -r 'if (.sites | type) == "array" then
        .sites[]?.name
    else
        .sites | keys[]
    end' "$config_file" 2>/dev/null
}

# Get site config by name
get_site_config() {
    local config_file="$1"
    local site_name="$2"

    if ! command -v jq &> /dev/null; then
        log_error "jq is required but not installed"
        return 1
    fi

    if [[ ! -f "$config_file" ]]; then
        return 1
    fi

    local site=$(jq 'if (.sites | type) == "array" then
        .sites[] | select(.name == "'$site_name'")
    else
        .sites."'$site_name'"
    end' "$config_file" 2>/dev/null)

    if [[ -n "$site" ]] && [[ "$site" != "null" ]]; then
        echo "$site"
        return 0
    fi

    return 1
}

# Check if site exists
site_exists() {
    local config_file="$1"
    local site_name="$2"

    if [[ ! -f "$config_file" ]]; then
        return 1
    fi

    if ! command -v jq &> /dev/null; then
        return 1
    fi

    local exists=$(jq 'if (.sites | type) == "array" then
        .sites[] | select(.name == "'$site_name'") | .name
    else
        .sites."'$site_name'" | select(. != null) | "found"
    end' "$config_file" 2>/dev/null)

    [[ -n "$exists" ]]
}

# Get project name
get_project_name() {
    local config_file="$1"
    get_config_value "$config_file" ".projectName" "fb"
}

# Get MySQL version
get_mysql_version() {
    local config_file="$1"
    get_config_value "$config_file" ".global.mysqlVersion" "5.7"
}

# Get default PHP version
get_default_php_version() {
    local config_file="$1"
    get_config_value "$config_file" ".global.phpVersions[0]" "8.1"
}

# Get all PHP versions
get_php_versions() {
    local config_file="$1"

    if ! command -v jq &> /dev/null; then
        log_error "jq is required"
        return 1
    fi

    jq -r '.global.phpVersions[]' "$config_file" 2>/dev/null
}

# Get admin user
get_admin_user() {
    local config_file="$1"
    get_config_value "$config_file" ".global.adminUser" "developer"
}

# Get admin password
get_admin_password() {
    local config_file="$1"
    get_config_value "$config_file" ".global.adminPassword" "Farmerdev#17"
}

# Create empty config file
create_empty_config() {
    local config_file="$1"

    cat > "$config_file" << 'EOF'
{
  "projectName": "fb",
  "global": {
    "phpVersions": ["8.1"],
    "mysqlVersion": "5.7",
    "defaultTheme": "fb",
    "adminUser": "developer",
    "adminPassword": "Farmerdev#17"
  },
  "sites": []
}
EOF

    log_success "Created config file: $config_file"
}

# Validate config structure
validate_config() {
    local config_file="$1"

    if ! command -v jq &> /dev/null; then
        log_error "jq is required"
        return 1
    fi

    if [[ ! -f "$config_file" ]]; then
        log_error "Config file not found: $config_file"
        return 1
    fi

    # Check if valid JSON
    if ! jq empty "$config_file" 2>/dev/null; then
        log_error "Invalid JSON in config file"
        return 1
    fi

    # Check required fields
    local has_project=$(jq 'has("projectName")' "$config_file")
    local has_global=$(jq 'has("global")' "$config_file")
    local has_sites=$(jq 'has("sites")' "$config_file")

    if [[ "$has_project" != "true" ]] || [[ "$has_global" != "true" ]] || [[ "$has_sites" != "true" ]]; then
        log_error "Config missing required fields"
        return 1
    fi

    log_success "Config validation passed"
    return 0
}
