#!/bin/bash

################################################################################
# fb-cli - Team-ready CLI for Docker LEMP WordPress development
# Version: 1.0.0 (Bash)
#
################################################################################

set -euo pipefail

# Script directory and project root
# PROJECT_ROOT is calculated dynamically from the script location, making this
# fully portable - can be installed anywhere without modification
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_DIR="${PROJECT_ROOT}/.fb"


source "$CONFIG_DIR/lib/logger.sh"
source "$CONFIG_DIR/lib/docker-utils.sh"
source "$CONFIG_DIR/lib/config.sh"
source "$CONFIG_DIR/lib/database-manager.sh"
source "$CONFIG_DIR/lib/wordpress.sh"
source "$CONFIG_DIR/lib/generator.sh"
source "$CONFIG_DIR/lib/ftp-manager.sh"

# Configuration files
SITES_CONFIG="$CONFIG_DIR/sites.config.json"
ENV_FILE="$CONFIG_DIR/.env"
DOCKER_COMPOSE_FILE="$CONFIG_DIR/docker-compose.yml"

# Directories
WWW_DIR="$PROJECT_ROOT/www"
BACKUPS_DIR="$CONFIG_DIR/backups"
SCRIPTS_DIR="$CONFIG_DIR/scripts"
NGINX_DIR="$CONFIG_DIR/nginx"
NGINX_SITES_ENABLED="$NGINX_DIR/sites-enabled"
CERT_DIR="$CONFIG_DIR/cert"
LIB_DIR="$CONFIG_DIR/lib"


################################################################################
# LOAD COMMAND MODULES
################################################################################

# Source helpers and all command modules
source "$CONFIG_DIR/commands/helpers.sh"
source "$CONFIG_DIR/commands/init.sh"
source "$CONFIG_DIR/commands/start.sh"
source "$CONFIG_DIR/commands/site.sh"
source "$CONFIG_DIR/commands/db.sh"
source "$CONFIG_DIR/commands/config.sh"
source "$CONFIG_DIR/commands/plugins.sh"

# Sync files and media from remote FTP server
cmd_sync() {
    if [[ $# -eq 0 ]]; then
        printf "${CYAN}fb-cli sync${NC} - Sync media and database from remote FTP\n"
        printf "\n${BLUE}USAGE:${NC}\n"
        printf "    fb-cli sync [SITE_NAME]\n"
        printf "\n${BLUE}DESCRIPTION:${NC}\n"
        printf "    Downloads WordPress media from remote FTP server using credentials\n"
        printf "    configured in sites.config.json under onlineFtpCredentials\n"
        printf "\n${BLUE}REQUIREMENTS:${NC}\n"
        printf "    - onlineFtpCredentials configured in sites.config.json with:\n"
        printf "      { \"host\": \"...\", \"user\": \"...\", \"password\": \"...\", \"mediaPath\": \"...\" }\n"
        printf "\n${BLUE}EXAMPLE:${NC}\n"
        printf "    fb-cli sync mysite\n"
        printf "\n"
        return 0
    fi

    local site_name="$1"

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found in configuration"
        return 1
    fi

    local site=$(get_site "$site_name")
    local site_dir="$WWW_DIR/$site_name"

    # Check if site directory exists
    if [[ ! -d "$site_dir" ]]; then
        log_error "Site directory not found: $site_dir"
        return 1
    fi

    # Get FTP credentials from site config
    local ftp_credentials=$(echo "$site" | jq '.onlineFtpCredentials // empty')

    if [[ -z "$ftp_credentials" ]] || [[ "$ftp_credentials" == "null" ]]; then
        log_error "No FTP credentials configured for site: $site_name"
        log_info "Add onlineFtpCredentials to sites.config.json:"
        printf '
    "onlineFtpCredentials": {
      "host": "ftp.example.com",
      "user": "ftp_user",
      "password": "ftp_password",
      "mediaPath": "/wp-content/uploads",
      "databaseDumpPath": "/db-dump.sql.gz"
    }
'
        return 1
    fi

    log_section "Syncing Site: $site_name"

    # Call the sync function
    if sync_site_from_remote "$site_name" "$site_dir" "$ftp_credentials" "$SITES_CONFIG"; then
        log_success "Site '$site_name' synced successfully!"
        log_info "Media downloaded to: $site_dir/wp-content/uploads"
        return 0
    else
        log_error "Failed to sync site: $site_name"
        return 1
    fi
}

# Helper function for adding sites to config
add_site_to_config() {
    local site_name="$1"
    local domain="$2"
    local php_version="$3"

    local temp_file=$(mktemp)
    jq '.sites."'$site_name'" = {
        "domain": "'$domain'",
        "phpVersion": "'$php_version'",
        "dbName": "'${site_name}_wp'",
        "dbUser": "root",
        "dbPassword": "Admin123"
    }' "$SITES_CONFIG" > "$temp_file"
    mv "$temp_file" "$SITES_CONFIG"
}

# Helper function for adding full site config
add_site_to_config_full() {
    local site_name="$1"
    local domain="$2"
    local php_version="$3"
    local db_name="$4"
    local admin_email="$5"
    local fresh_install="${6:-true}"
    local remote_server="${7:-}"
    local ftp_host="${8:-}"
    local ftp_user="${9:-}"
    local ftp_pass="${10:-}"
    local ftp_path="${11:-/public_html/wp-content/uploads}"

    # Build FTP credentials JSON object
    local ftp_credentials='null'
    if [[ -n "$ftp_host" ]]; then
        ftp_credentials=$(printf '{"host":"%s","user":"%s","password":"%s","path":"%s"}' \
            "$ftp_host" "$ftp_user" "$ftp_pass" "$ftp_path")
    fi

    local temp_file=$(mktemp)

    jq --arg sitename "$site_name" \
       --arg domain "$domain" \
       --arg phpVersion "$php_version" \
       --arg dbName "$db_name" \
       --arg dbUser "root" \
       --arg dbPassword "Admin123" \
       --arg adminEmail "$admin_email" \
       --arg fresh "$fresh_install" \
       --arg remote "$remote_server" \
       --argjson ftpcreds "$ftp_credentials" \
       '.sites[$sitename] = {
           "domain": $domain,
           "phpVersion": $phpVersion,
           "dbName": $dbName,
           "dbUser": $dbUser,
           "dbPassword": $dbPassword,
           "adminEmail": $adminEmail,
           "freshInstall": ($fresh == "true"),
           "theme": {
                "repo": "git@github.com:Farmerbit/flynt-gutenberg-starter.git",
                "name": "farmerbit"
            },
           "createdAt": (now | todate),
           "adminPassword": "Farmerdev#17",
           "permalinkStructure": "/%postname%/",
           "remoteServer": (if $remote == "null" then null else $remote end),
           "onlineFtpCredentials": $ftpcreds
       }' "$SITES_CONFIG" > "$temp_file"

    mv "$temp_file" "$SITES_CONFIG"
    log_success "Site added to configuration"
}

################################################################################
# MAIN ROUTER
################################################################################

main() {
    # Load environment
    load_env "$ENV_FILE"

    # No arguments - show help
    if [[ $# -eq 0 ]]; then
        show_help
        exit 0
    fi

    local command="$1"
    shift || true

    case "$command" in
        init) cmd_init "$@" ;;
        site) cmd_site "$@" ;;
        start) cmd_start "$@" ;;
        restart) cmd_restart "$@" ;;
        stop) cmd_stop "$@" ;;
        db) cmd_db "$@" ;;
        sync) cmd_sync "$@" ;;
        config) cmd_config "$@" ;;
        plugins) cmd_plugins "$@" ;;
        --help|-h) show_help ;;
        --version|-v) show_version ;;
        *)
            log_error "Unknown command: $command"
            printf "\n"
            show_help
            exit 1
            ;;
    esac
}

################################################################################
# LOAD LIBRARIES
################################################################################

# Source all required libraries
[[ -f "$LIB_DIR/database-manager.sh" ]] && source "$LIB_DIR/database-manager.sh"
[[ -f "$LIB_DIR/wordpress.sh" ]] && source "$LIB_DIR/wordpress.sh"
[[ -f "$LIB_DIR/site-installer.sh" ]] && source "$LIB_DIR/site-installer.sh"

################################################################################
# Execute main
################################################################################

main "$@"
