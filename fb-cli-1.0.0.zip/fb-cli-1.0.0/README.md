# fb-cli - Team-ready CLI for Docker LEMP WordPress Development

Version: 1.0.0

## Quick Start

### 1. Installation

```bash
# Extract the archive
unzip fb-cli-1.0.0.zip
cd fb-cli-1.0.0

# Run installer
./INSTALL.sh

# Or specify custom directory
./INSTALL.sh /path/to/installation
```

### 2. Initialize Project

```bash
cd $INSTALL_DIR
fb-cli init
```

Answer the prompts:
- Project name
- MySQL version
- Node.js version
- PHP memory limit
- PHP upload max size

### 3. Start Development Environment

```bash
fb-cli start
```

### 4. Create Your First Site

```bash
fb-cli site add mysite
```

## Commands

- `fb-cli init` - Initialize new project
- `fb-cli start` - Start Docker containers
- `fb-cli stop` - Stop Docker containers
- `fb-cli site add [NAME]` - Add new WordPress site
- `fb-cli site remove [NAME]` - Remove WordPress site
- `fb-cli site list` - List all sites
- `fb-cli db backup [SITE]` - Backup database
- `fb-cli db restore [SITE]` - Restore database
- `fb-cli sync [SITE]` - Sync media from remote FTP

## Configuration

Edit `$INSTALL_DIR/.fb/sites.config.json` to configure:
- WordPress themes
- Plugins
- PHP versions per site
- Database credentials
- FTP credentials for sync

## Documentation

See `PROJECT_ANALYSIS.md` for comprehensive project documentation.

## System Requirements

- Docker & Docker Compose
- Bash 4.0+
- wget or curl
- jq (JSON processor)

## Troubleshooting

Run with debug mode:
```bash
bash -x $(which fb-cli) [COMMAND]
```

View logs:
```bash
docker compose logs -f [SERVICE]
```

Check configuration:
```bash
cat .fb/sites.config.json | jq
```

## Support

For issues, check:
1. Docker is running: `docker ps`
2. Docker Compose is installed: `docker compose version`
3. Port conflicts: `netstat -an | grep 3306`
4. File permissions: `ls -la .fb/`
