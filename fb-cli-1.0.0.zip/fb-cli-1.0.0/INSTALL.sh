#!/bin/bash

set -euo pipefail

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}fb-cli Installation${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Detect installation directory
INSTALL_DIR="${1:-.}"
if [[ "$INSTALL_DIR" == "." ]]; then
    INSTALL_DIR="$HOME/fb-cli"
fi

echo -e "${BLUE}Installation directory: $INSTALL_DIR${NC}"
echo ""

# Create installation directory
mkdir -p "$INSTALL_DIR"

# Copy files
echo -e "${YELLOW}Installing files...${NC}"
cp -r .fb "$INSTALL_DIR/"
cp fb-cli.sh "$INSTALL_DIR/"
cp .gitignore "$INSTALL_DIR/" 2>/dev/null || true

# Make fb-cli executable
chmod +x "$INSTALL_DIR/fb-cli.sh"

# Create www directory
mkdir -p "$INSTALL_DIR/www"

# Create symlink or add to PATH
if [[ -d "$HOME/.local/bin" ]]; then
    echo -e "${YELLOW}Creating symlink in ~/.local/bin${NC}"
    ln -sf "$INSTALL_DIR/fb-cli.sh" "$HOME/.local/bin/fb-cli"

    if ! echo "$PATH" | grep -q "$HOME/.local/bin"; then
        echo ""
        echo -e "${YELLOW}⚠️  Add ~/.local/bin to your PATH:${NC}"
        echo -e "  ${BLUE}export PATH=\"\$HOME/.local/bin:\$PATH\"${NC}"
        echo ""
    fi
else
    echo -e "${YELLOW}Suggestion: Add to your PATH or create alias:${NC}"
    echo -e "  ${BLUE}alias fb-cli=\"$INSTALL_DIR/fb-cli.sh\"${NC}"
fi

echo ""
echo -e "${GREEN}✓ Installation complete!${NC}"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo -e "  1. cd $INSTALL_DIR"
echo -e "  2. fb-cli init"
echo -e "  3. fb-cli start"
echo ""
