#!/bin/bash

################################################################################
# COMMAND: PLUGINS
# Plugin management (install, activate, list)
################################################################################

cmd_plugins() {
    if [[ $# -eq 0 ]]; then
        printf "${CYAN}fb-cli plugins${NC} - Plugin management\n"
        printf "\n${BLUE}USAGE:${NC}\n"
        printf "    fb-cli plugins [SUBCOMMAND] [SITE_NAME]\n"
        printf "\n${BLUE}SUBCOMMANDS:${NC}\n"
        printf "    install [NAME]      Install configured plugins\n"
        printf "    activate [NAME]     Activate all plugins\n"
        printf "    list [NAME]         List installed plugins\n"
        printf "\n"
        return
    fi

    local subcommand="$1"
    shift || true

    case "$subcommand" in
        install) cmd_plugins_install "$@" ;;
        activate) cmd_plugins_activate "$@" ;;
        list) cmd_plugins_list "$@" ;;
        *)
            log_error "Unknown subcommand: $subcommand"
            return 1
            ;;
    esac
}

cmd_plugins_install() {
    check_docker_compose || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    log_info "Installing plugins for: $site_name..."

    local site_config=$(get_site "$site_name")
    local plugins=$(echo "$site_config" | jq -r '.plugins[]?.slug // empty')

    if [[ -z "$plugins" ]]; then
        log_warn "No plugins configured for this site"
        return
    fi

    local wp_path="$WWW_DIR/$site_name"
    local php_container=$(get_php_container_for_site "$site_name")

    while IFS= read -r plugin; do
        log_info "Installing: $plugin"
        docker_exec "$DOCKER_COMPOSE_FILE" "$php_container" wp plugin install "$plugin" --activate --path="$wp_path" --allow-root 2>/dev/null || \
            log_warn "Failed to install: $plugin"
    done <<< "$plugins"

    log_success "Plugin installation completed"
}

cmd_plugins_activate() {
    check_docker_compose || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    log_info "Activating plugins for: $site_name..."

    local wp_path="$WWW_DIR/$site_name"
    local php_container=$(get_php_container_for_site "$site_name")

    docker_exec "$DOCKER_COMPOSE_FILE" "$php_container" wp plugin activate --all --path="$wp_path" --allow-root 2>/dev/null

    log_success "Plugins activated"
}

cmd_plugins_list() {
    check_docker_compose || return 1

    local site_name="${1:-}"
    if [[ -z "$site_name" ]]; then
        site_name=$(prompt "Site name")
    fi

    if ! site_exists "$site_name"; then
        log_error "Site '$site_name' not found"
        return 1
    fi

    log_section "Installed Plugins: $site_name"

    local wp_path="$WWW_DIR/$site_name"
    local php_container=$(get_php_container_for_site "$site_name")

    docker_exec "$DOCKER_COMPOSE_FILE" "$php_container" wp plugin list --path="$wp_path" --allow-root
}
