#!/bin/bash

################################################################################
# Logger Library - Utility functions for colored output
################################################################################

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

################################################################################
# Logging Functions
################################################################################

log_info() {
    printf "${CYAN}ℹ  $*${NC}\n"
}

log_success() {
    printf "${GREEN}✓ $*${NC}\n"
}

log_warn() {
    printf "${YELLOW}⚠  $*${NC}\n"
}

log_error() {
    printf "${RED}✗ $*${NC}\n" >&2
}

log_section() {
    printf "\n${BLUE}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    printf "${BLUE}${BOLD}$*${NC}\n"
    printf "${BLUE}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n\n"
}

log_debug() {
    if [[ "${DEBUG:-0}" == "1" ]]; then
        printf "${YELLOW}[DEBUG]${NC} $*\n" >&2
    fi
}


show_help() {
    printf "${CYAN}fb-cli${NC} - Team-ready CLI for Docker LEMP WordPress development\n"
    printf "Version: 1.0.0\n"
    printf "\n"
    printf "${BLUE}USAGE:${NC}\n"
    printf "    fb-cli [COMMAND] [OPTIONS]\n"
    printf "\n"
    printf "${BLUE}COMMANDS:${NC}\n"
    printf "    init                Initialize new project\n"
    printf "    site                Manage WordPress sites\n"
    printf "    start               Start Docker containers\n"
    printf "    stop                Stop Docker containers\n"
    printf "    db                  Database operations\n"
    printf "    sync                File synchronization\n"
    printf "    config              Configuration management\n"
    printf "    plugins             Plugin management\n"
    printf "    --help              Show this help\n"
    printf "    --version           Show version\n"
    printf "\n"
    printf "${BLUE}EXAMPLES:${NC}\n"
    printf "    fb-cli init                        Initialize project\n"
    printf "    fb-cli site add mysite             Add WordPress site\n"
    printf "    fb-cli site list                   List all sites\n"
    printf "    fb-cli start                       Start containers\n"
    printf "    fb-cli db backup mysite            Backup database\n"
    printf "    fb-cli config show                 Show configuration\n"
    printf "\n"
}


# Print separator
log_separator() {
    echo "────────────────────────────────────────────────────────"
}

# Prompt yes/no
prompt_confirm() {
    local message="$1"
    local default="${2:-n}"

    local prompt_text="$message (y/n)"
    [[ "$default" == "y" ]] && prompt_text="$message (Y/n)" || prompt_text="$message (y/N)"

    read -p "$prompt_text: " -n 1 -r
    echo

    if [[ $REPLY =~ ^[Yy]$ ]]; then
        return 0
    else
        return 1
    fi
}

# Prompt user for input
prompt() {
    local message="$1"
    local default="${2:-}"
    local input

    if [[ -n "$default" ]]; then
        read -p "$message [$default]: " input
        echo "${input:-$default}"
    else
        read -p "$message: " input
        echo "$input"
    fi
}



################################################################################
# HELP AND VERSION
################################################################################

show_version() {
    echo "fb-cli version 1.0.0"
}